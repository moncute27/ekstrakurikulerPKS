<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Galeri extends Model
{
    protected $table = 'galeris';

    protected $fillable = ['judul', 'gambar', 'keterangan', 'tanggal'];

    protected $casts = ['tanggal' => 'date'];
}
