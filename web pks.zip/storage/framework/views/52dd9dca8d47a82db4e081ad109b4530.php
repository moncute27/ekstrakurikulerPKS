<article class="card">

    <a href="<?php echo e(route('berita.show', $item)); ?>" class="card__media">
        <?php if($item->gambar): ?>
            <img src="<?php echo e(asset($item->gambar)); ?>" alt="<?php echo e($item->judul); ?>" loading="lazy">
        <?php else: ?>
            <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="<?php echo e($item->judul); ?>" loading="lazy">
        <?php endif; ?>
    </a>

    <div class="card__body">
        <span class="chip chip--navy"><?php echo e($item->kategori); ?></span>

        <h3 style="margin-top:.6rem;">
            <a href="<?php echo e(route('berita.show', $item)); ?>"><?php echo e($item->judul); ?></a>
        </h3>

        <p><?php echo e(\Illuminate\Support\Str::limit($item->ringkasan ?: strip_tags($item->isi), 120)); ?></p>

        <div class="card__meta">
            <span><?php echo e($item->tanggal?->translatedFormat('d M Y')); ?></span>
            <a href="<?php echo e(route('berita.show', $item)); ?>" class="card__link">Baca →</a>
        </div>
    </div>

</article>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/kartu-berita.blade.php ENDPATH**/ ?>