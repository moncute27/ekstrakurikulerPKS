<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Beranda'); ?> — <?php echo e($profil->nama_ekskul ?? 'Ekstrakurikuler PKS'); ?></title>

    <link rel="icon" href="<?php echo e(asset($profil->logo ?: 'img/logo pks.jpeg')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/public.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>

<header class="site-header">
    <div class="container site-header__inner">

        <a href="<?php echo e(route('beranda')); ?>" class="brand">
            <img src="<?php echo e(asset($profil->logo ?: 'img/logo pks.jpeg')); ?>" alt="Logo PKS">
            <span class="brand__text">
                <strong><?php echo e($profil->nama_ekskul ?: 'Ekstrakurikuler PKS'); ?></strong>
                <span><?php echo e($profil->nama_sekolah ?: 'SMKN 2 Purwakarta'); ?></span>
            </span>
        </a>

        <button class="nav-toggle" id="navToggle" type="button" aria-label="Buka menu">☰</button>

        <nav class="main-nav" id="mainNav">
            <a href="<?php echo e(route('beranda')); ?>" class="<?php echo e(request()->routeIs('beranda') ? 'is-active' : ''); ?>">Beranda</a>
            <a href="<?php echo e(route('profil')); ?>" class="<?php echo e(request()->routeIs('profil') ? 'is-active' : ''); ?>">Profil</a>
            <a href="<?php echo e(route('organisasi')); ?>" class="<?php echo e(request()->routeIs('organisasi') ? 'is-active' : ''); ?>">Organisasi</a>
            <a href="<?php echo e(route('berita.index')); ?>" class="<?php echo e(request()->routeIs('berita.*') ? 'is-active' : ''); ?>">Berita</a>
            <a href="<?php echo e(route('galeri')); ?>" class="<?php echo e(request()->routeIs('galeri') ? 'is-active' : ''); ?>">Galeri</a>
            <a href="<?php echo e(route('prestasi')); ?>" class="<?php echo e(request()->routeIs('prestasi') ? 'is-active' : ''); ?>">Prestasi</a>
            <a href="<?php echo e(route('anggota')); ?>" class="<?php echo e(request()->routeIs('anggota') ? 'is-active' : ''); ?>">Anggota</a>
            <a href="<?php echo e(route('agenda')); ?>" class="<?php echo e(request()->routeIs('agenda') ? 'is-active' : ''); ?>">Agenda</a>

            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="nav-login">Dashboard</a>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>" class="nav-login">Login</a>
            <?php endif; ?>
        </nav>

    </div>
</header>

<?php echo $__env->yieldContent('content'); ?>

<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">

            <div>
                <h4><?php echo e($profil->nama_ekskul ?: 'Ekstrakurikuler PKS'); ?></h4>
                <p><?php echo e($profil->deskripsi_singkat ?: 'Patroli Keamanan Sekolah (PKS) membina karakter, kepemimpinan, dan kedisiplinan siswa.'); ?></p>
            </div>

            <div>
                <h4>Navigasi</h4>
                <ul class="footer-links">
                    <li><a href="<?php echo e(route('profil')); ?>">Profil</a></li>
                    <li><a href="<?php echo e(route('organisasi')); ?>">Struktur Organisasi</a></li>
                    <li><a href="<?php echo e(route('berita.index')); ?>">Berita</a></li>
                    <li><a href="<?php echo e(route('prestasi')); ?>">Prestasi</a></li>
                    <li><a href="<?php echo e(route('agenda')); ?>">Agenda</a></li>
                </ul>
            </div>

            <div>
                <h4>Kontak</h4>
                <ul class="footer-links">
                    <?php if($profil->alamat): ?><li>📍 <?php echo e($profil->alamat); ?></li><?php endif; ?>
                    <?php if($profil->telepon): ?><li>📞 <?php echo e($profil->telepon); ?></li><?php endif; ?>
                    <?php if($profil->email): ?><li>✉️ <?php echo e($profil->email); ?></li><?php endif; ?>
                    <?php if($profil->instagram): ?><li>📷 <?php echo e($profil->instagram); ?></li><?php endif; ?>
                </ul>
            </div>

        </div>

        <div class="footer-bottom">
            © <?php echo e(date('Y')); ?> <?php echo e($profil->nama_ekskul ?: 'Ekstrakurikuler PKS'); ?> — <?php echo e($profil->nama_sekolah ?: 'SMKN 2 Purwakarta'); ?>. Seluruh hak cipta dilindungi.
        </div>
    </div>
</footer>

<script>
    (function () {
        const toggle = document.getElementById('navToggle');
        const nav = document.getElementById('mainNav');

        if (toggle && nav) {
            toggle.addEventListener('click', () => nav.classList.toggle('is-open'));
            nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('is-open')));
        }
    })();
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/layouts/public.blade.php ENDPATH**/ ?>