<?php $__env->startSection('title', 'Beranda'); ?>

<?php $__env->startSection('content'); ?>

    <section class="hero">
        <img class="hero__bg" src="<?php echo e(asset($profil->foto_header ?: 'img/poto pkss.jpg')); ?>" alt="Kegiatan Ekstrakurikuler PKS">

        <div class="container hero__content">
            <span class="badge">★ Patroli Keamanan Sekolah</span>

            <h1>
                <?php echo e(strtoupper($profil->nama_ekskul ?: 'Ekstrakurikuler PKS')); ?><br>
                <span><?php echo e(strtoupper($profil->nama_sekolah ?: 'SMKN 2 Purwakarta')); ?></span>
            </h1>

            <p><?php echo e($profil->visi ?: 'Membentuk siswa yang disiplin, bertanggung jawab, dan berkarakter melalui kegiatan Patroli Keamanan Sekolah.'); ?></p>

            <div class="hero__actions">
                <a href="<?php echo e(route('profil')); ?>" class="btn btn--primary">Kenali Kami</a>
                <a href="<?php echo e(route('berita.index')); ?>" class="btn btn--ghost">Berita Terbaru</a>
            </div>
        </div>
    </section>

    
    <section class="section section--tight section--alt">
        <div class="container">
            <div class="stats">
                <div class="stat">
                    <div class="stat__icon">👥</div>
                    <div class="stat__value"><?php echo e($jumlahAnggota); ?></div>
                    <div class="stat__label">Anggota Aktif</div>
                </div>
                <div class="stat">
                    <div class="stat__icon">🏆</div>
                    <div class="stat__value"><?php echo e($jumlahPrestasi); ?></div>
                    <div class="stat__label">Prestasi Diraih</div>
                </div>
                <div class="stat">
                    <div class="stat__icon">📅</div>
                    <div class="stat__value"><?php echo e($jumlahAgenda); ?></div>
                    <div class="stat__label">Agenda Kegiatan</div>
                </div>
                <div class="stat">
                    <div class="stat__icon">🖼️</div>
                    <div class="stat__value"><?php echo e($jumlahGaleri); ?></div>
                    <div class="stat__label">Dokumentasi</div>
                </div>
            </div>
        </div>
    </section>

    
    <section class="section">
        <div class="container">

            <div class="section-head">
                <div class="section-head__eyebrow">Informasi</div>
                <h2>Berita Terbaru</h2>
                <p>Kabar terkini seputar kegiatan dan pencapaian ekstrakurikuler PKS.</p>
            </div>

            <?php if($beritaTerbaru->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">📰</div>
                    <p>Belum ada berita yang dipublikasikan.</p>
                </div>
            <?php else: ?>
                <div class="grid grid--3">
                    <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-berita', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div style="text-align:center;margin-top:2rem;">
                    <a href="<?php echo e(route('berita.index')); ?>" class="btn btn--outline">Lihat Semua Berita</a>
                </div>
            <?php endif; ?>

        </div>
    </section>

    
    <?php if($agendaTerdekat->isNotEmpty()): ?>
        <section class="section section--alt">
            <div class="container">

                <div class="section-head">
                    <div class="section-head__eyebrow">Jadwal</div>
                    <h2>Agenda Terdekat</h2>
                    <p>Kegiatan yang akan segera dilaksanakan oleh anggota PKS.</p>
                </div>

                <div class="grid" style="gap:1rem;">
                    <?php $__currentLoopData = $agendaTerdekat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-agenda', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div style="text-align:center;margin-top:2rem;">
                    <a href="<?php echo e(route('agenda')); ?>" class="btn btn--outline">Lihat Semua Agenda</a>
                </div>

            </div>
        </section>
    <?php endif; ?>

    
    <?php if($galeriSorot->isNotEmpty()): ?>
        <section class="section">
            <div class="container">

                <div class="section-head">
                    <div class="section-head__eyebrow">Dokumentasi</div>
                    <h2>Galeri Kegiatan</h2>
                    <p>Momen-momen yang terekam dari berbagai kegiatan PKS.</p>
                </div>

                <div class="gallery">
                    <?php $__currentLoopData = $galeriSorot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <figure>
                            <img src="<?php echo e(asset($foto->gambar)); ?>" alt="<?php echo e($foto->judul); ?>" loading="lazy">
                            <figcaption><?php echo e($foto->judul); ?></figcaption>
                        </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div style="text-align:center;margin-top:2rem;">
                    <a href="<?php echo e(route('galeri')); ?>" class="btn btn--outline">Lihat Galeri Lengkap</a>
                </div>

            </div>
        </section>
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/beranda.blade.php ENDPATH**/ ?>