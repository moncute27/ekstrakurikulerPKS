<div class="agenda-item <?php echo e(($item->tanggal && $item->tanggal->isPast()) ? 'agenda-item--past' : ''); ?>">

    <div class="date-box">
        <div class="d"><?php echo e($item->tanggal?->format('d')); ?></div>
        <div class="m"><?php echo e($item->tanggal?->translatedFormat('M')); ?></div>
        <div class="y"><?php echo e($item->tanggal?->format('Y')); ?></div>
    </div>

    <div>
        <h3><?php echo e($item->judul); ?></h3>

        <?php if($item->deskripsi): ?>
            <p><?php echo e($item->deskripsi); ?></p>
        <?php endif; ?>

        <div class="agenda-meta">
            <?php if($item->waktu): ?>
                <span>🕒 <?php echo e(\Illuminate\Support\Carbon::parse($item->waktu)->format('H:i')); ?> WIB</span>
            <?php endif; ?>
            <?php if($item->lokasi): ?>
                <span>📍 <?php echo e($item->lokasi); ?></span>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/kartu-agenda.blade.php ENDPATH**/ ?>