<?php
    $menu = [
        ['route' => 'admin.dashboard', 'aktif' => 'admin.dashboard', 'ikon' => '⌂', 'label' => 'Dashboard'],
    ];

    $menuKonten = [
        ['route' => 'admin.profil.edit', 'aktif' => 'admin.profil.*', 'ikon' => '🏫', 'label' => 'Profil Ekskul'],
        ['route' => 'admin.pengurus.index', 'aktif' => 'admin.pengurus.*', 'ikon' => '🎖️', 'label' => 'Struktur Organisasi'],
        ['route' => 'admin.berita.index', 'aktif' => 'admin.berita.*', 'ikon' => '📰', 'label' => 'Berita'],
        ['route' => 'admin.galeri.index', 'aktif' => 'admin.galeri.*', 'ikon' => '🖼️', 'label' => 'Galeri'],
        ['route' => 'admin.prestasi.index', 'aktif' => 'admin.prestasi.*', 'ikon' => '🏆', 'label' => 'Prestasi'],
        ['route' => 'admin.anggota.index', 'aktif' => 'admin.anggota.*', 'ikon' => '👥', 'label' => 'Anggota'],
        ['route' => 'admin.agenda.index', 'aktif' => 'admin.agenda.*', 'ikon' => '📅', 'label' => 'Agenda'],
    ];
?>

<aside class="sidebar" id="sidebar">

    <div class="sidebar__brand">
        <img src="<?php echo e(asset($profil->logo ?: 'img/logo pks.jpeg')); ?>" alt="Logo PKS">
        <div>
            <strong>Admin PKS</strong>
            <span><?php echo e($profil->nama_sekolah ?: 'SMKN 2 Purwakarta'); ?></span>
        </div>
    </div>

    <nav class="sidebar__nav">

        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>" class="<?php echo e(request()->routeIs($item['aktif']) ? 'is-active' : ''); ?>">
                <span class="ic"><?php echo e($item['ikon']); ?></span>
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="sidebar__label">Kelola Konten</div>

        <?php $__currentLoopData = $menuKonten; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($item['route'])); ?>" class="<?php echo e(request()->routeIs($item['aktif']) ? 'is-active' : ''); ?>">
                <span class="ic"><?php echo e($item['ikon']); ?></span>
                <span><?php echo e($item['label']); ?></span>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(auth()->user()->isAdmin()): ?>
            <div class="sidebar__label">Pengaturan</div>

            <a href="<?php echo e(route('admin.user.index')); ?>" class="<?php echo e(request()->routeIs('admin.user.*') ? 'is-active' : ''); ?>">
                <span class="ic">🔑</span>
                <span>Manajemen User</span>
            </a>
        <?php endif; ?>

    </nav>

    <div class="sidebar__foot">
        <form method="POST" action="<?php echo e(route('logout')); ?>" data-confirm="Yakin ingin keluar dari panel admin?">
            <?php echo csrf_field(); ?>
            <button type="submit" class="logout-btn">
                <span>⇥</span>
                <span>Logout</span>
            </button>
        </form>
    </div>

</aside>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/admin-sidebar.blade.php ENDPATH**/ ?>