<div class="person">
    <?php if($orang->foto): ?>
        <img src="<?php echo e(asset($orang->foto)); ?>" alt="<?php echo e($orang->nama); ?>" class="person__photo" loading="lazy">
    <?php else: ?>
        <div class="person__avatar"><?php echo e(strtoupper(substr($orang->nama, 0, 1))); ?></div>
    <?php endif; ?>

    <h3><?php echo e($orang->nama); ?></h3>
    <div class="person__role"><?php echo e($orang->jabatan); ?></div>

    <?php if($orang->periode): ?>
        <div class="person__period">Periode <?php echo e($orang->periode); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/kartu-pengurus.blade.php ENDPATH**/ ?>