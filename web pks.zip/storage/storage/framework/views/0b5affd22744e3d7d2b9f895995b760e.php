<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin PKS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('backend/dashboard.css')); ?>">
</head>
<body>

    <div class="dashboard-container">

        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="brand">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
                <div class="brand-text">
                    <h2>ADMIN PKS</h2>
                    <p>Ekstrakurikuler pks</p>
                    <p>SMKN 2 PURWAKARTA</p>
                </div>
            </div>

            <nav class="sidebar-nav">
                <a href="<?php echo e(url('/dashboard')); ?>" class="nav-item active">
                    <i class="fa-solid fa-house"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo e(url('/backendprofil')); ?>" class="nav-item">
                    <i class="fa-regular fa-user"></i>
                    <span>Profil</span>
                </a>
                <a href="<?php echo e(url('/backendorganisasi')); ?>" class="nav-item">
                    <i class="fa-solid fa-table-columns"></i>
                    <span>Organisasi</span>
                </a>
                <a href="<?php echo e(url('/backendberita')); ?>" class="nav-item">
                    <i class="fa-regular fa-newspaper"></i>
                    <span>Berita</span>
                </a>
                <a href="<?php echo e(url('/backendgaleri')); ?>" class="nav-item">
                    <i class="fa-regular fa-image"></i>
                    <span>Galeri</span>
                </a>
                <a href="<?php echo e(url('/backendprestasi')); ?>" class="nav-item">
                    <i class="fa-solid fa-trophy"></i>
                    <span>Prestasi</span>
                </a>
                <a href="<?php echo e(url('/backendanggota')); ?>" class="nav-item">
                    <i class="fa-solid fa-users"></i>
                    <span>Anggota</span>
                </a>
                <a href="<?php echo e(url('/backendagenda')); ?>" class="nav-item">
                    <i class="fa-regular fa-calendar"></i>
                    <span>Agenda</span>
                </a>
                <a href="<?php echo e(url('/backenduser')); ?>" class="nav-item">
                    <i class="fa-solid fa-user-gear"></i>
                    <span>User</span>
                </a>
            </nav>

            <a href="<?php echo e(url('/logout')); ?>" class="nav-item logout">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>
        </aside>

        <!-- MAIN CONTENT AREA -->
        <main class="main-content">

            <!-- TOPBAR -->
            <header class="topbar">
                <button class="hamburger">
                    <i class="fa-solid fa-bars"></i>
                </button>

                <div class="top-right">
                    <i class="fa-solid fa-bell notification"></i>
                    <div class="admin-info">
                        <i class="fa-regular fa-circle-user"></i>
                        <div>
                            <strong>Admin PKS</strong>
                            <span>Administrator</span>
                        </div>
                        <i class="fa-solid fa-chevron-down"></i>
                    </div>
                </div>
            </header>

            <!-- CONTENT BODY -->
            <div class="content-body">
                <div class="welcome">
                    <h1>Selamat Datang, Admin PKS! 👋</h1>
                    <p>Kelola seluruh informasi Ekstrakurikuler PKS dengan mudah dan cepat.</p>
                </div>

                <div class="line"></div>

                <div class="menu-title">
                    <h2>Menu Kelola Data</h2>
                    <p>Pilih menu di bawah ini untuk mengelola data ekstrakurikuler PKS.</p>
                </div>

                <!-- CARDS GRID -->
                <div class="cards-grid">

                    <div class="card">
                        <i class="fa-regular fa-file-lines"></i>
                        <h3>Profil</h3>
                        <p>Kelola informasi profil ekstrakurikuler PKS.</p>
                        <a href="<?php echo e(url('/backendprofil')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-solid fa-users"></i>
                        <h3>Organisasi</h3>
                        <p>Kelola struktur organisasi dan kepengurusan PKS.</p>
                        <a href="<?php echo e(url('/backendorganisasi')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-regular fa-newspaper"></i>
                        <h3>Berita</h3>
                        <p>Kelola berita dan informasi kegiatan terbaru.</p>
                        <a href="<?php echo e(url('/backendberita')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-regular fa-image"></i>
                        <h3>Galeri</h3>
                        <p>Kelola dokumentasi foto kegiatan PKS.</p>
                        <a href="<?php echo e(url('/backendgaleri')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-solid fa-trophy"></i>
                        <h3>Prestasi</h3>
                        <p>Kelola data prestasi dan penghargaan yang diraih.</p>
                        <a href="<?php echo e(url('/backendprestasi')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-solid fa-users"></i>
                        <h3>Anggota</h3>
                        <p>Kelola data anggota ekstrakurikuler PKS.</p>
                        <a href="<?php echo e(url('/backendanggota')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-regular fa-calendar"></i>
                        <h3>Agenda</h3>
                        <p>Kelola agenda dan jadwal kegiatan PKS.</p>
                        <a href="<?php echo e(url('/backendagenda')); ?>">Kelola Data &rarr;</a>
                    </div>

                    <div class="card">
                        <i class="fa-solid fa-user-gear"></i>
                        <h3>User</h3>
                        <p>Kelola akun admin dan pengguna sistem.</p>
                        <a href="<?php echo e(url('/backenduser')); ?>">Kelola Data &rarr;</a>
                    </div>

                </div>
            </div>

        </main>
    </div>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>