<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?php echo e($profil->nama_ekskul ?: 'Ekstrakurikuler PKS'); ?></title>

    <link rel="icon" href="<?php echo e(asset($profil->logo ?: 'img/logo pks.jpeg')); ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('css/public.css')); ?>">
</head>
<body>

<div class="auth-page">
    <div>

        <div class="auth-card">

            <img src="<?php echo e(asset($profil->logo ?: 'img/logo pks.jpeg')); ?>" alt="Logo PKS" class="auth-card__logo">

            <h1>Masuk Panel Admin</h1>
            <p class="auth-card__sub"><?php echo e($profil->nama_ekskul ?: 'Ekstrakurikuler PKS'); ?> — <?php echo e($profil->nama_sekolah ?: 'SMKN 2 Purwakarta'); ?></p>

            <?php if(session('sukses')): ?>
                <div class="alert alert--success"><?php echo e(session('sukses')); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="field">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                           placeholder="admin@pks.test" required autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <label class="field-inline">
                    <input type="checkbox" name="remember" value="1">
                    <span>Ingat saya di perangkat ini</span>
                </label>

                <button type="submit" class="btn btn--primary btn-block">Masuk</button>
            </form>

            <div class="auth-hint">
                <strong>Akun demo (hasil seeder):</strong><br>
                Admin — admin@pks.test / admin12345<br>
                Pengurus — pengurus@pks.test / pengurus12345<br>
                <em>Segera ganti password ini di halaman Manajemen User.</em>
            </div>

        </div>

        <a href="<?php echo e(route('beranda')); ?>" class="auth-back">← Kembali ke beranda</a>

    </div>
</div>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/auth/login.blade.php ENDPATH**/ ?>