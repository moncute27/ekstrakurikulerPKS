<?php $__env->startSection('title', 'Kelola Anggota'); ?>
<?php $__env->startSection('subtitle', 'Data anggota Ekstrakurikuler PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Kelola Anggota</h1>
            <p>Total <?php echo e($anggota->total()); ?> anggota terdaftar.</p>
        </div>

        <a href="<?php echo e(route('admin.anggota.create')); ?>" class="btn btn--gold">+ Tambah Anggota</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.anggota.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari nama, NIS, atau kelas...">

            <select name="status">
                <option value="">Semua Status</option>
                <?php $__currentLoopData = \App\Models\Anggota::STATUS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($opsi); ?>" <?php if($status === $opsi): echo 'selected'; endif; ?>><?php echo e($opsi); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit" class="btn btn--primary">Filter</button>
            <?php if($cari || $status): ?>
                <a href="<?php echo e(route('admin.anggota.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($anggota->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">👥</div>
                <p>Tidak ada data anggota yang cocok.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th style="width:60px;">No</th>
                            <th>Nama</th>
                            <th>NIS</th>
                            <th>Kelas</th>
                            <th>Jabatan</th>
                            <th>Angkatan</th>
                            <th>Status</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($anggota->firstItem() + $i); ?></td>
                                <td>
                                    <div class="cell-user" style="display:flex;align-items:center;gap:.7rem;">
                                        <?php if($item->foto): ?>
                                            <img src="<?php echo e(asset($item->foto)); ?>" alt="" class="thumb thumb--round">
                                        <?php else: ?>
                                            <span class="thumb-empty" style="width:40px;border-radius:50%;">
                                                <?php echo e(strtoupper(substr($item->nama, 0, 1))); ?>

                                            </span>
                                        <?php endif; ?>
                                        <strong><?php echo e($item->nama); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo e($item->nis ?: '—'); ?></td>
                                <td><?php echo e($item->kelas); ?></td>
                                <td><?php echo e($item->jabatan); ?></td>
                                <td><?php echo e($item->angkatan); ?></td>
                                <td>
                                    <span class="badge <?php echo e($item->status === 'Aktif' ? 'badge--green' : 'badge--grey'); ?>">
                                        <?php echo e($item->status); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="td-actions">
                                        <a href="<?php echo e(route('admin.anggota.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <form method="POST" action="<?php echo e(route('admin.anggota.destroy', $item)); ?>"
                                              data-confirm="Hapus anggota &quot;<?php echo e($item->nama); ?>&quot;?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($anggota->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/anggota/index.blade.php ENDPATH**/ ?>