<?php $__env->startSection('title', 'Kelola Galeri'); ?>
<?php $__env->startSection('subtitle', 'Dokumentasi foto kegiatan PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Kelola Galeri</h1>
            <p>Total <?php echo e($galeri->total()); ?> foto tersimpan.</p>
        </div>

        <a href="<?php echo e(route('admin.galeri.create')); ?>" class="btn btn--gold">+ Tambah Foto</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.galeri.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari judul foto...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.galeri.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <div class="panel__body">
            <?php if($galeri->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">🖼️</div>
                    <p>Belum ada foto di galeri.</p>
                </div>
            <?php else: ?>
                <div class="media-grid">
                    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="media-card">
                            <img src="<?php echo e(asset($item->gambar)); ?>" alt="<?php echo e($item->judul); ?>" loading="lazy">

                            <div class="media-card__body">
                                <strong><?php echo e(\Illuminate\Support\Str::limit($item->judul, 34)); ?></strong>
                                <small><?php echo e($item->tanggal?->translatedFormat('d M Y') ?: 'Tanpa tanggal'); ?></small>

                                <div class="media-card__actions">
                                    <a href="<?php echo e(route('admin.galeri.edit', $item)); ?>" class="btn btn--light btn--sm">Edit</a>
                                    <form method="POST" action="<?php echo e(route('admin.galeri.destroy', $item)); ?>"
                                          data-confirm="Hapus foto &quot;<?php echo e($item->judul); ?>&quot;?">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn--danger btn--sm">Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>

        <?php if($galeri->hasPages()): ?>
            <div class="pagination-wrap"><?php echo e($galeri->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/galeri/index.blade.php ENDPATH**/ ?>