<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Berita - Ekstrakurikuler PKS</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
          rel="stylesheet">

    <!-- CSS -->
    <link rel="stylesheet" href="berita.css">
</head>

<body>

    <div class="page">

        <!-- ================= HEADER ================= -->
        <header class="header">

            <!-- Foto bagian atas -->
            <img src="img/POTO PKS3.jpeg"
                 alt="Kegiatan PKS"
                 class="header-image">


            <!-- Logo PKS -->
            <img src="img/logo pks.jpeg"
                 alt="Logo PKS"
                 class="logo">


            <!-- ================= NAVBAR ================= -->
            <nav class="navbar">

                <a href="beranda">Beranda</a>

                <a href="profil">Profil</a>

                <a href="organisasi">Organisasi</a>

                <a href="berita" class="active">
                    Berita
                </a>

                <a href="galeri">Galeri</a>

                <a href="prestasi">Prestasi</a>

                <a href="anggota">Anggota</a>

                <a href="agenda">Agenda</a>

                <a href="user">user</a>

            </nav>

        </header>


        <!-- ================= BERITA ================= -->
        <main class="news-section">

            <h1>BERITA TERBARU</h1>

            <div class="title-line"></div>


            <!-- ================= KATEGORI ================= -->
            <div class="categories">

                <button class="category active">
                    Semua
                </button>

                <button class="category">
                    Kegiatan
                </button>

                <button class="category">
                    Pengumuman
                </button>

            </div>


            <!-- ================= DAFTAR BERITA ================= -->
            <div class="news-container">


                <!-- ===== BERITA 1 ===== -->
                <article class="news-card">

                    <img src="img/smk2.jpeg"
                         alt="Kegiatan Latihan Diksar PKS"
                         class="news-image">

                    <div class="news-content">

                        <h2>
                            Penyerahan piala olimpiade smart student
                        </h2>

                        <p>
                            PKS menerima penghargaan dalam kegiatan
                            olimpiade smart student sebagai bentuk
                            apresiasi atas prestasi yang telah diraih.
                        </p>

                    </div>

                </article>


                <!-- ===== BERITA 2 ===== -->
                <article class="news-card">

                    <img src="img/ppbb.jpeg"
                         alt="Pelantikan Pengurus PKS"
                         class="news-image">

                    <div class="news-content">

                        <h2>
                            Peringatan HUT bhayangkara ke-81
                        </h2>

                        <p>
                            PKS turut berpasitipasi dalam kegiatan
                            peringatan HUT bhayangkara ke-81
                        </p>

                    </div>

                </article>


                <!-- ===== BERITA 3 ===== -->
                <article class="news-card">

                    <img src="img/honey.jpeg"
                         alt="Penerimaan penghargaan lomba PKS"
                         class="news-image">

                    <div class="news-content">

                        <h2>
                            Serah terima jabatan pengurus PKS
                        </h2>

                        <p>
                            Kegiatan serah terima jabatan sebagai bagian
                            dari pergantian dan pelantikan kepengurusan PKS.
                        </p>

                    </div>

                </article>

            </div>

        </main>

    </div>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/berita.blade.php ENDPATH**/ ?>