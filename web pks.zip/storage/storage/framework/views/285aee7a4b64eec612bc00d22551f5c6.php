<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Anggota - Admin PKS</title>

    <link rel="stylesheet" href="<?php echo e(asset('backendanggota.css')); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
</head>

<body>

    <div class="admin-container">

        <!-- =========================
             SIDEBAR
        ========================== -->

        <aside class="sidebar" id="sidebar">

            <!-- Logo dan nama -->
            <div class="sidebar-header">

                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
                     alt="Logo PKS"
                     class="logo">

                <div class="admin-title">
                    <h3>ADMIN PKS</h3>
                    <p>Ekstrakurikuler pks</p>
                    <p>SMKN 2 PURWAKARTA</p>
                </div>

            </div>


            <!-- Menu -->
            <nav class="sidebar-menu">

                <a href="dashboard" class="menu-item">
                    <i class="fa-solid fa-house"></i>
                    <span>Dashboard</span>
                </a>

                <a href="profil" class="menu-item">
                    <i class="fa-regular fa-user"></i>
                    <span>Profil</span>
                </a>

                <a href="organisasi" class="menu-item">
                    <i class="fa-solid fa-table-list"></i>
                    <span>Organisasi</span>
                </a>

                <a href="berita" class="menu-item">
                    <i class="fa-solid fa-newspaper"></i>
                    <span>Berita</span>
                </a>

                <a href="galeri" class="menu-item">
                    <i class="fa-regular fa-image"></i>
                    <span>Galeri</span>
                </a>

                <a href="prestasi" class="menu-item">
                    <i class="fa-solid fa-trophy"></i>
                    <span>Prestasi</span>
                </a>

                <!-- MENU AKTIF -->
                <a href="anggota" class="menu-item active">
                    <i class="fa-solid fa-users"></i>
                    <span>Anggota</span>
                </a>

                <a href="agenda" class="menu-item">
                    <i class="fa-regular fa-calendar"></i>
                    <span>Agenda</span>
                </a>

                <a href="user" class="menu-item">
                    <i class="fa-solid fa-user-gear"></i>
                    <span>User</span>
                </a>

            </nav>


            <!-- Logout -->
            <a href="logout" class="logout">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Logout</span>
            </a>

        </aside>


        <!-- =========================
             BAGIAN KANAN
        ========================== -->

        <main class="main-content">

            <!-- =====================
                 TOPBAR
            ====================== -->

            <header class="topbar">

                <button class="menu-button" id="menuButton">
                    <i class="fa-solid fa-bars"></i>
                </button>


                <div class="topbar-right">

                    <i class="fa-solid fa-bell notification"></i>

                    <div class="admin-profile">

                        <i class="fa-solid fa-circle-user profile-icon"></i>

                        <div class="profile-text">
                            <span>Admin PKS</span>
                            <small>Administrator</small>
                        </div>

                        <i class="fa-solid fa-chevron-down arrow"></i>

                    </div>

                </div>

            </header>


            <!-- =====================
                 CONTENT
            ====================== -->

            <section class="content">

                <!-- Judul -->
                <div class="page-title">

                    <h1>Kelola Anggota</h1>

                    <p>
                        Kelola data anggota PKS.
                    </p>

                </div>


                <!-- =================
                     TOOLBAR
                ================== -->

                <div class="toolbar">

                    <!-- Tambah anggota -->
                    <button class="add-button">

                        <i class="fa-solid fa-plus"></i>

                        Tambah Anggota

                    </button>


                    <!-- Search -->
                    <div class="search-box">

                        <i class="fa-solid fa-magnifying-glass"></i>

                        <input
                            type="text"
                            id="searchInput"
                            placeholder="Cari anggota..."
                        >

                    </div>

                </div>


                <!-- Keterangan -->

                <p class="table-title">
                    Daftar Anggota PKS.
                </p>


                <!-- =================
                     TABLE
                ================== -->

                <div class="table-container">

                    <table class="member-table">

                        <thead>

                            <tr>
                                <th>No.</th>
                                <th>Nama</th>
                                <th>Kelas</th>
                                <th>Jenis Kelamin</th>
                                <th>Angkatan</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>

                        </thead>


                        <tbody id="memberTable">

                            <tr>
                                <td>1.</td>
                                <td>Tri Rahayu</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>2.</td>
                                <td>Dewi Surya</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>3.</td>
                                <td>Syifa Aulia</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>4.</td>
                                <td>Senda Triandari</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>5.</td>
                                <td>Nida Mutia</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>6.</td>
                                <td>Bunga</td>
                                <td>XI BR 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>7.</td>
                                <td>Defi</td>
                                <td>XI AK 2</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>8.</td>
                                <td>Tyra</td>
                                <td>XI BD 2</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>9.</td>
                                <td>Noval</td>
                                <td>XI AK 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>10.</td>
                                <td>Reina</td>
                                <td>XII MP</td>
                                <td>P</td>
                                <td>2024</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>11.</td>
                                <td>Dipi</td>
                                <td>XII MP</td>
                                <td>P</td>
                                <td>2024</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>12.</td>
                                <td>Lulu Keyrani</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>13.</td>
                                <td>Mufidatul</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>14.</td>
                                <td>Zikra</td>
                                <td>XI BD 1</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>


                            <tr>
                                <td>15.</td>
                                <td>Fitri</td>
                                <td>XI RPL 2</td>
                                <td>P</td>
                                <td>2025</td>
                                <td>
                                    <span class="status aktif">
                                        Aktif
                                    </span>
                                </td>
                                <td>
                                    <div class="actions">
                                        <button class="edit">
                                            <i class="fa-solid fa-pen"></i>
                                        </button>

                                        <button class="delete">
                                            <i class="fa-solid fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>

                        </tbody>

                    </table>

                </div>

            </section>

        </main>

    </div>


    <!-- =========================
         JAVASCRIPT
         SEMENTARA UNTUK SEARCH
    ========================== -->

    <script>

        const menuButton = document.getElementById("menuButton");
        const sidebar = document.getElementById("sidebar");

        menuButton.addEventListener("click", function () {

            sidebar.classList.toggle("show");

        });


        /* =========================
           SEARCH ANGGOTA
        ========================== */

        const searchInput = document.getElementById("searchInput");
        const rows = document.querySelectorAll("#memberTable tr");

        searchInput.addEventListener("keyup", function () {

            const keyword = this.value.toLowerCase();

            rows.forEach(function (row) {

                const text = row.textContent.toLowerCase();

                if (text.includes(keyword)) {

                    row.style.display = "";

                } else {

                    row.style.display = "none";

                }

            });

        });

    </script>

</body>

</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backendanggota.blade.php ENDPATH**/ ?>