<section class="page-hero">
    <img class="page-hero__bg" src="<?php echo e(asset($profil->foto_header ?: 'img/POTO PKS3.jpeg')); ?>" alt="">

    <div class="container">
        <div class="breadcrumb">
            <a href="<?php echo e(route('beranda')); ?>">Beranda</a> / <span><?php echo e($judul); ?></span>
        </div>

        <h1><?php echo e($judul); ?></h1>

        <?php if(isset($sub)): ?>
            <p><?php echo e($sub); ?></p>
        <?php endif; ?>
    </div>
</section>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/page-hero.blade.php ENDPATH**/ ?>