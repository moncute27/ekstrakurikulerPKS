<?php $__env->startSection('title', 'Prestasi'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Prestasi PKS',
        'sub' => 'Pencapaian anggota PKS dari tingkat sekolah hingga nasional.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <div class="filter-bar">
                <a href="<?php echo e(route('prestasi')); ?>" class="<?php echo e($tingkatAktif === 'Semua' ? 'is-active' : ''); ?>">Semua</a>
                <?php $__currentLoopData = \App\Models\Prestasi::TINGKAT; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tingkat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('prestasi', ['tingkat' => $tingkat])); ?>"
                       class="<?php echo e($tingkatAktif === $tingkat ? 'is-active' : ''); ?>"><?php echo e($tingkat); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($prestasi->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">🏆</div>
                    <p>Belum ada prestasi pada kategori ini.</p>
                </div>
            <?php else: ?>
                <div class="grid grid--2">
                    <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="trophy-card">
                            <div class="trophy-card__icon">🏆</div>

                            <div>
                                <span class="chip">🏅 <?php echo e($item->tingkat); ?><?php echo e($item->tahun ? ' · '.$item->tahun : ''); ?></span>

                                <h3><?php echo e($item->judul); ?></h3>

                                <?php if($item->penyelenggara): ?>
                                    <p style="font-weight:600;color:var(--navy-600);font-size:.82rem;"><?php echo e($item->penyelenggara); ?></p>
                                <?php endif; ?>

                                <?php if($item->keterangan): ?>
                                    <p><?php echo e($item->keterangan); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/prestasi.blade.php ENDPATH**/ ?>