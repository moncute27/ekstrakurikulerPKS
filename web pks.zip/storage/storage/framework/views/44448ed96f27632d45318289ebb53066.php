<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Prestasi - Admin PKS</title>

    <link rel="stylesheet" href="<?php echo e(asset('backendprestasi.css')); ?>">
</head>

<body>

<div class="admin-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <div class="sidebar-header">

            <div class="logo">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
            </div>

            <div class="admin-name">
                <h3>ADMIN PKS</h3>
                <p>Ekstrakurikuler pks</p>
                <p>SMKN 2 PURWAKARTA</p>
            </div>

        </div>


        <!-- MENU SIDEBAR -->
        <nav class="sidebar-menu">

            <a href="dashboard" class="menu-item">
                <span class="menu-icon">⌂</span>
                <span>Dashboard</span>
            </a>

            <a href="profil" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>Profil</span>
            </a>

            <a href="organisasi" class="menu-item">
                <span class="menu-icon">▱</span>
                <span>Organisasi</span>
            </a>

            <a href="berita" class="menu-item">
                <span class="menu-icon">▤</span>
                <span>Berita</span>
            </a>

            <a href="galeri" class="menu-item">
                <span class="menu-icon">▣</span>
                <span>Galeri</span>
            </a>

            <a href="prestasi" class="menu-item active">
                <span class="menu-icon">♛</span>
                <span>Prestasi</span>
            </a>

            <a href="anggota" class="menu-item">
                <span class="menu-icon">♟</span>
                <span>Anggota</span>
            </a>

            <a href="agenda" class="menu-item">
                <span class="menu-icon">□</span>
                <span>Agenda</span>
            </a>

            <a href="user" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>User</span>
            </a>

        </nav>


        <!-- LOGOUT -->
        <div class="logout">

            <a href="logout">
                <span class="logout-icon">⇥</span>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">


        <!-- ================= TOPBAR ================= -->
        <header class="topbar">

            <button class="menu-toggle" id="menuToggle">
                ☰
            </button>

            <div class="topbar-right">

                <span class="notification">
                    ♟
                </span>

                <div class="profile-admin">

                    <span class="user-icon">
                        ●
                    </span>

                    <div class="admin-account">
                        <strong>Admin PKS</strong>
                        <small>Administrator</small>
                    </div>

                    <span class="arrow">
                        ⌄
                    </span>

                </div>

            </div>

        </header>


        <!-- ================= PRESTASI ================= -->
        <section class="achievement-content">


            <!-- JUDUL -->
            <div class="achievement-heading">

                <div>
                    <h1>Kelola Prestasi</h1>

                    <p>
                        Kelola data prestasi yang diraih oleh PKS.
                    </p>
                </div>

            </div>


            <!-- ================= AKSI ATAS ================= -->
            <div class="achievement-toolbar">

                <!-- TAMBAH PRESTASI -->
                <button class="add-achievement-button">
                    <span>+</span>
                    Tambah Prestasi
                </button>


                <!-- SEARCH -->
                <div class="achievement-search">

                    <span class="achievement-search-icon">
                        ⌕
                    </span>

                    <input
                        type="text"
                        placeholder="Cari prestasi..."
                    >

                </div>

            </div>


            <!-- ================= FILTER ================= -->
            <div class="achievement-filter">

                <button class="filter-button active-filter">
                    Semua
                </button>

                <button class="filter-button">
                    Kabupaten
                </button>

                <button class="filter-button">
                    Provinsi
                </button>

                <button class="filter-button">
                    Nasional
                </button>

            </div>


            <!-- ================= DAFTAR PRESTASI ================= -->
            <div class="achievement-list">


                <!-- PRESTASI 1 -->
                <div class="achievement-item">

                    <div class="achievement-trophy">
                        🏆
                    </div>


                    <div class="achievement-information">

                        <h3>
                            Juara 1 PBB Terbaik
                        </h3>

                        <span class="achievement-level">
                            Kabupaten
                        </span>

                        <p>
                            Lomba PBB antar sekolah tingkat kabupaten
                        </p>

                    </div>


                    <div class="achievement-actions">

                        <button class="achievement-edit">
                            ✎ <span>Edit</span>
                        </button>

                        <button class="achievement-delete">
                            ▣ <span>Hapus</span>
                        </button>

                    </div>

                </div>


                <!-- PRESTASI 2 -->
                <div class="achievement-item">

                    <div class="achievement-trophy">
                        🏆
                    </div>


                    <div class="achievement-information">

                        <h3>
                            Juara 3 Danton Terbaik
                        </h3>

                        <span class="achievement-level">
                            Provinsi
                        </span>

                        <p>
                            Lomba Danton tingkat provinsi
                        </p>

                    </div>


                    <div class="achievement-actions">

                        <button class="achievement-edit">
                            ✎ <span>Edit</span>
                        </button>

                        <button class="achievement-delete">
                            ▣ <span>Hapus</span>
                        </button>

                    </div>

                </div>


                <!-- PRESTASI 3 -->
                <div class="achievement-item">

                    <div class="achievement-trophy">
                        🏆
                    </div>


                    <div class="achievement-information">

                        <h3>
                            Juara Madya 3 SE Jawa Barat
                        </h3>

                        <span class="achievement-level">
                            Provinsi
                        </span>

                        <p>
                            Lomba PBB tingkat SE Jawa Barat
                        </p>

                    </div>


                    <div class="achievement-actions">

                        <button class="achievement-edit">
                            ✎ <span>Edit</span>
                        </button>

                        <button class="achievement-delete">
                            ▣ <span>Hapus</span>
                        </button>

                    </div>

                </div>


                <!-- PRESTASI 4 -->
                <div class="achievement-item">

                    <div class="achievement-trophy">
                        🏆
                    </div>


                    <div class="achievement-information">

                        <h3>
                            Juara 2 Senam Terbaik Kab.Purwakarta
                        </h3>

                        <span class="achievement-level">
                            Kabupaten
                        </span>

                        <p>
                            Lomba senam antar sekolah tingkat kabupaten purwakarta
                        </p>

                    </div>


                    <div class="achievement-actions">

                        <button class="achievement-edit">
                            ✎ <span>Edit</span>
                        </button>

                        <button class="achievement-delete">
                            ▣ <span>Hapus</span>
                        </button>

                    </div>

                </div>


            </div>

        </section>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    const menuToggle = document.getElementById("menuToggle");
    const sidebar = document.querySelector(".sidebar");

    menuToggle.addEventListener("click", function () {

        sidebar.classList.toggle("show");

    });

</script>

</body>

</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backendprestasi.blade.php ENDPATH**/ ?>