<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Galeri - PKS SMKN 2 Purwakarta</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo e(asset('galeri.css')); ?>">
</head>

<body>

<div class="container">

    <!-- HEADER -->
    <header class="header">

        <img
            src="<?php echo e(asset('img/POTO PKS3.jpeg')); ?>"
            class="header-img"
            alt="Header PKS"
        >

        <img
            src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
            class="logo"
            alt="Logo PKS"
        >

        <nav class="navbar">
            <a href="/beranda">Beranda</a>
            <a href="/profil">Profil</a>
            <a href="/organisasi">Organisasi</a>
            <a href="/berita">Berita</a>
            <a href="/galeri" class="active">Galeri</a>
            <a href="/prestasi">Prestasi</a>
            <a href="/anggota">Anggota</a>
            <a href="/agenda">Agenda</a>
            
        </nav>

    </header>


    <!-- GALERI -->
    <section class="galeri">

        <h1>GALERI KEGIATAN</h1>

        <div class="garis"></div>


        <div class="galeri-grid">

            <!-- 1 -->
            <div class="item">
                <img src="<?php echo e(asset('img/smk2.jpeg')); ?>" alt="">
                <p>
                    Dokumentasi penyerahan piala
                    lomba olimpiade smart student
                </p>
            </div>


            <!-- 2 -->
            <div class="item">
                <img src="<?php echo e(asset('img/ppbb.jpeg')); ?>" alt="">
                <p>
                    Dokumentasi peringatan HUT
                    bhayangkara ke-81
                </p>
            </div>


            <!-- 3 -->
            <div class="item">
                <img src="<?php echo e(asset('img/plisi.jpg')); ?>" alt="">
                <p>
                    Dokumentasi peringatan HUT
                    bhayangkara ke-81
                </p>
            </div>


            <!-- 4 -->
            <div class="item">
                <img src="<?php echo e(asset('img/smkn222.jpeg')); ?>" alt="">
                <p>
                    Dokumentasi penyerahan piala
                    lomba olimpiade smart student
                </p>
            </div>


            <!-- 5 -->
            <div class="item">
                <img src="<?php echo e(asset('img/plisi2.jpg')); ?>" alt="">
                <p>
                    Dokumentasi demo ekstrakurikuler
                </p>
            </div>


            <!-- 6 -->
            <div class="item">
                <img src="<?php echo e(asset('img/honey.jpeg')); ?>" alt="">
                <p>
                    Dokumentasi serah terima
                    jabatan
                </p>
            </div>

        </div>


        <button class="btn-more">
            Lihat lebih banyak
        </button>

    </section>

</div>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/galeri.blade.php ENDPATH**/ ?>