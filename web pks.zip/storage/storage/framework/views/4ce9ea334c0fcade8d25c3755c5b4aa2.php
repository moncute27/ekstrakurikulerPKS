<?php $__env->startSection('title', 'Berita'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Berita Terbaru',
        'sub' => 'Kabar kegiatan, pengumuman, dan pencapaian Ekstrakurikuler PKS.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <form class="search-form" method="GET" action="<?php echo e(route('berita.index')); ?>">
                <input type="text" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari judul berita...">
                <input type="hidden" name="kategori" value="<?php echo e($kategoriAktif); ?>">
                <button type="submit" class="btn btn--outline">Cari</button>
            </form>

            <div class="filter-bar">
                <a href="<?php echo e(route('berita.index', ['cari' => $cari])); ?>"
                   class="<?php echo e($kategoriAktif === 'Semua' ? 'is-active' : ''); ?>">Semua</a>

                <?php $__currentLoopData = \App\Models\Berita::KATEGORI; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('berita.index', ['kategori' => $kategori, 'cari' => $cari])); ?>"
                       class="<?php echo e($kategoriAktif === $kategori ? 'is-active' : ''); ?>"><?php echo e($kategori); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php if($berita->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">📰</div>
                    <p>Tidak ada berita yang cocok dengan pencarian Anda.</p>
                </div>
            <?php else: ?>
                <div class="grid grid--3">
                    <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-berita', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="pagination-wrap"><?php echo e($berita->links()); ?></div>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/berita.blade.php ENDPATH**/ ?>