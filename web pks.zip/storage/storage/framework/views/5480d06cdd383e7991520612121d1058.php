<?php $__env->startSection('title', 'Struktur Organisasi'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Struktur Organisasi',
        'sub' => 'Susunan pembina, pelatih, dan pengurus Ekstrakurikuler PKS.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <?php if($pengurus->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">🎖️</div>
                    <p>Data struktur organisasi belum diisi.</p>
                </div>
            <?php else: ?>
                <?php
                    $pimpinan = $pengurus->filter(fn ($p) => in_array($p->jabatan, ['Pembina', 'Pelatih']));
                    $inti = $pengurus->reject(fn ($p) => in_array($p->jabatan, ['Pembina', 'Pelatih']));
                ?>

                <?php if($pimpinan->isNotEmpty()): ?>
                    <div class="section-head">
                        <div class="section-head__eyebrow">Pembimbing</div>
                        <h2>Pembina &amp; Pelatih</h2>
                    </div>

                    <div class="grid grid--4" style="margin-bottom:3rem;">
                        <?php $__currentLoopData = $pimpinan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('partials.kartu-pengurus', ['orang' => $orang], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <?php if($inti->isNotEmpty()): ?>
                    <div class="section-head">
                        <div class="section-head__eyebrow">Kepengurusan</div>
                        <h2>Pengurus Inti</h2>
                    </div>

                    <div class="grid grid--4">
                        <?php $__currentLoopData = $inti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo $__env->make('partials.kartu-pengurus', ['orang' => $orang], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/organisasi.blade.php ENDPATH**/ ?>