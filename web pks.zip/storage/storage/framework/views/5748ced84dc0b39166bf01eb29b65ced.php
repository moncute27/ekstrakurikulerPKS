<?php $__env->startSection('title', $pengurus->exists ? 'Edit Pengurus' : 'Tambah Pengurus'); ?>
<?php $__env->startSection('subtitle', 'Struktur organisasi Ekstrakurikuler PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1><?php echo e($pengurus->exists ? 'Edit Pengurus' : 'Tambah Pengurus'); ?></h1>
            <p>Isi data pengurus yang akan ditampilkan pada halaman Struktur Organisasi.</p>
        </div>

        <a href="<?php echo e(route('admin.pengurus.index')); ?>" class="btn btn--light">← Kembali</a>
    </div>

    <form method="POST"
          action="<?php echo e($pengurus->exists ? route('admin.pengurus.update', $pengurus) : route('admin.pengurus.store')); ?>"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($pengurus->exists): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="panel">
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nama">Nama Lengkap <span class="req">*</span></label>
                        <input type="text" id="nama" name="nama" value="<?php echo e(old('nama', $pengurus->nama)); ?>" required>
                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="jabatan">Jabatan <span class="req">*</span></label>
                        <input type="text" id="jabatan" name="jabatan" list="daftarJabatan"
                               value="<?php echo e(old('jabatan', $pengurus->jabatan)); ?>" required>
                        <datalist id="daftarJabatan">
                            <option value="Pembina"></option>
                            <option value="Pelatih"></option>
                            <option value="Ketua"></option>
                            <option value="Wakil Ketua"></option>
                            <option value="Sekretaris"></option>
                            <option value="Bendahara"></option>
                            <option value="Humas"></option>
                        </datalist>
                        <?php $__errorArgs = ['jabatan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field">
                        <label for="periode">Periode</label>
                        <input type="text" id="periode" name="periode" value="<?php echo e(old('periode', $pengurus->periode)); ?>" placeholder="2025/2026">
                    </div>

                    <div class="field <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="urutan">Urutan Tampil</label>
                        <input type="number" id="urutan" name="urutan" min="0" max="999"
                               value="<?php echo e(old('urutan', $pengurus->urutan ?? 0)); ?>">
                        <span class="hint">Angka lebih kecil tampil lebih dulu.</span>
                        <?php $__errorArgs = ['urutan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field field--full <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="foto">Foto</label>
                        <input type="file" id="foto" name="foto" accept="image/*" data-preview="#previewFoto">
                        <span class="hint">Opsional. JPG/PNG/WEBP maksimal 2 MB.</span>
                        <div class="preview">
                            <img id="previewFoto" src="<?php echo e($pengurus->foto ? asset($pengurus->foto) : ''); ?>"
                                 alt="" style="<?php echo e($pengurus->foto ? '' : 'display:none;'); ?>">
                        </div>
                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="form-actions">
                    <a href="<?php echo e(route('admin.pengurus.index')); ?>" class="btn btn--light">Batal</a>
                    <button type="submit" class="btn btn--primary">
                        <?php echo e($pengurus->exists ? 'Simpan Perubahan' : 'Simpan Pengurus'); ?>

                    </button>
                </div>
            </div>
        </div>

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/pengurus/form.blade.php ENDPATH**/ ?>