<?php $__env->startSection('title', $item->exists ? 'Edit Foto Galeri' : 'Tambah Foto Galeri'); ?>
<?php $__env->startSection('subtitle', 'Dokumentasi kegiatan PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1><?php echo e($item->exists ? 'Edit Foto' : 'Tambah Foto'); ?></h1>
            <p>Foto akan tampil di halaman Galeri dan sorotan beranda.</p>
        </div>

        <a href="<?php echo e(route('admin.galeri.index')); ?>" class="btn btn--light">← Kembali</a>
    </div>

    <form method="POST"
          action="<?php echo e($item->exists ? route('admin.galeri.update', $item) : route('admin.galeri.store')); ?>"
          enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php if($item->exists): ?>
            <?php echo method_field('PUT'); ?>
        <?php endif; ?>

        <div class="panel">
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="judul">Judul Foto <span class="req">*</span></label>
                        <input type="text" id="judul" name="judul" value="<?php echo e(old('judul', $item->judul)); ?>" required>
                        <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="tanggal">Tanggal Kegiatan</label>
                        <input type="date" id="tanggal" name="tanggal"
                               value="<?php echo e(old('tanggal', optional($item->tanggal)->format('Y-m-d'))); ?>">
                        <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field field--full <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="keterangan">Keterangan</label>
                        <textarea id="keterangan" name="keterangan" rows="3" maxlength="500"><?php echo e(old('keterangan', $item->keterangan)); ?></textarea>
                        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field field--full <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="gambar">Gambar <?php if(! $item->exists): ?><span class="req">*</span><?php endif; ?></label>
                        <input type="file" id="gambar" name="gambar" accept="image/*"
                               data-preview="#previewGambar" <?php if(! $item->exists): ?> required <?php endif; ?>>
                        <span class="hint">JPG/PNG/WEBP maksimal 4 MB.</span>
                        <div class="preview">
                            <img id="previewGambar" src="<?php echo e($item->gambar ? asset($item->gambar) : ''); ?>"
                                 alt="" style="<?php echo e($item->gambar ? '' : 'display:none;'); ?>">
                        </div>
                        <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="form-actions">
                    <a href="<?php echo e(route('admin.galeri.index')); ?>" class="btn btn--light">Batal</a>
                    <button type="submit" class="btn btn--primary">
                        <?php echo e($item->exists ? 'Simpan Perubahan' : 'Unggah Foto'); ?>

                    </button>
                </div>
            </div>
        </div>

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/galeri/form.blade.php ENDPATH**/ ?>