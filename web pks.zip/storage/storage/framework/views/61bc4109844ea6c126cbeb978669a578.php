<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('subtitle', 'Ringkasan data website Ekstrakurikuler PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Halo, <?php echo e(auth()->user()->name); ?> 👋</h1>
            <p>Berikut ringkasan data yang tersimpan di database saat ini.</p>
        </div>

        <a href="<?php echo e(route('admin.berita.create')); ?>" class="btn btn--gold">+ Tulis Berita</a>
    </div>

    <div class="stat-grid">
        <?php $__currentLoopData = $statistik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($stat['route']); ?>" class="stat-card">
                <span class="ic"><?php echo e($stat['ikon']); ?></span>
                <div>
                    <div class="val"><?php echo e($stat['nilai']); ?></div>
                    <div class="lbl"><?php echo e($stat['label']); ?></div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="two-col">

        <div class="panel">
            <div class="panel__head">
                <h3>Berita Terbaru</h3>
                <a href="<?php echo e(route('admin.berita.index')); ?>" class="btn btn--light btn--sm">Kelola</a>
            </div>
            <div class="panel__body">
                <?php if($beritaTerbaru->isEmpty()): ?>
                    <div class="empty">
                        <div class="empty__icon">📰</div>
                        <p>Belum ada berita.</p>
                    </div>
                <?php else: ?>
                    <ul class="mini-list">
                        <?php $__currentLoopData = $beritaTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <?php if($item->gambar): ?>
                                    <img src="<?php echo e(asset($item->gambar)); ?>" alt="" class="thumb">
                                <?php else: ?>
                                    <span class="thumb-empty">📰</span>
                                <?php endif; ?>
                                <div style="flex:1;min-width:0;">
                                    <strong><?php echo e(\Illuminate\Support\Str::limit($item->judul, 48)); ?></strong>
                                    <small><?php echo e($item->tanggal?->translatedFormat('d M Y')); ?> · <?php echo e($item->penulis); ?></small>
                                </div>
                                <span class="badge <?php echo e($item->is_published ? 'badge--green' : 'badge--grey'); ?>">
                                    <?php echo e($item->is_published ? 'Terbit' : 'Draf'); ?>

                                </span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="panel">
            <div class="panel__head">
                <h3>Agenda Terdekat</h3>
                <a href="<?php echo e(route('admin.agenda.index')); ?>" class="btn btn--light btn--sm">Kelola</a>
            </div>
            <div class="panel__body">
                <?php if($agendaTerdekat->isEmpty()): ?>
                    <div class="empty">
                        <div class="empty__icon">📅</div>
                        <p>Belum ada agenda mendatang.</p>
                    </div>
                <?php else: ?>
                    <ul class="mini-list">
                        <?php $__currentLoopData = $agendaTerdekat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <div class="mini-date">
                                    <?php echo e($item->tanggal?->format('d')); ?>

                                    <span><?php echo e($item->tanggal?->translatedFormat('M')); ?></span>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <strong><?php echo e(\Illuminate\Support\Str::limit($item->judul, 44)); ?></strong>
                                    <small><?php echo e($item->lokasi ?: 'Lokasi belum ditentukan'); ?></small>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>