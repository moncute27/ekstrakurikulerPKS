<?php $__env->startSection('title', 'Profil'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Profil Ekstrakurikuler',
        'sub' => $detail->deskripsi_singkat,
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container profile-grid">

            <div class="prose">
                <h2>Tentang <?php echo e($detail->nama_ekskul); ?></h2>
                <?php $__empty_1 = true; $__currentLoopData = preg_split('/\r\n|\r|\n/', (string) $detail->sejarah); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if(trim($paragraf) !== ''): ?>
                        <p><?php echo e($paragraf); ?></p>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>Belum ada deskripsi.</p>
                <?php endif; ?>

                <?php if($detail->visi): ?>
                    <h2>Visi</h2>
                    <p><?php echo e($detail->visi); ?></p>
                <?php endif; ?>

                <?php if(count($detail->misiList())): ?>
                    <h2>Misi</h2>
                    <ul class="check-list">
                        <?php $__currentLoopData = $detail->misiList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $misi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($misi); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <aside>
                <ul class="info-list">
                    <li>
                        <span class="ic">🏫</span>
                        <div>
                            <span>Sekolah</span>
                            <strong><?php echo e($detail->nama_sekolah); ?></strong>
                        </div>
                    </li>
                    <li>
                        <span class="ic">👥</span>
                        <div>
                            <span>Ekstrakurikuler</span>
                            <strong><?php echo e($detail->nama_ekskul); ?></strong>
                        </div>
                    </li>
                    <?php if($detail->alamat): ?>
                        <li>
                            <span class="ic">📍</span>
                            <div>
                                <span>Alamat</span>
                                <strong><?php echo e($detail->alamat); ?></strong>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if($detail->telepon): ?>
                        <li>
                            <span class="ic">📞</span>
                            <div>
                                <span>Telepon</span>
                                <strong><?php echo e($detail->telepon); ?></strong>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if($detail->email): ?>
                        <li>
                            <span class="ic">✉️</span>
                            <div>
                                <span>Email</span>
                                <strong><?php echo e($detail->email); ?></strong>
                            </div>
                        </li>
                    <?php endif; ?>
                    <?php if($detail->instagram): ?>
                        <li>
                            <span class="ic">📷</span>
                            <div>
                                <span>Instagram</span>
                                <strong><?php echo e($detail->instagram); ?></strong>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>

                <div style="margin-top:1.2rem;">
                    <a href="<?php echo e(route('organisasi')); ?>" class="btn btn--outline btn-block">Lihat Struktur Organisasi</a>
                </div>
            </aside>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/profil.blade.php ENDPATH**/ ?>