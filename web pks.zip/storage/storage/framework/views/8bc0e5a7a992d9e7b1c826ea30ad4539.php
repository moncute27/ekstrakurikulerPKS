<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola User - Admin PKS</title>

    <!-- Font Awesome -->
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backenduser.css')); ?>">

    <style>
        /* ================= MODAL ================= */

        .modal {
            display: none;
            position: fixed;
            z-index: 999;
            inset: 0;
            background: rgba(0, 0, 0, 0.55);
            align-items: center;
            justify-content: center;
        }

        .modal.show {
            display: flex;
        }

        .modal-content {
            width: 90%;
            max-width: 500px;
            background: white;
            border-radius: 12px;
            padding: 25px;
            box-sizing: border-box;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header h2 {
            margin: 0;
            font-size: 22px;
        }

        .close-modal {
            border: none;
            background: none;
            font-size: 25px;
            cursor: pointer;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 6px;
            font-weight: bold;
        }

        .form-group input,
        .form-group select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 6px;
            box-sizing: border-box;
        }

        .modal-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }

        .btn-cancel,
        .btn-save {
            border: none;
            padding: 10px 18px;
            border-radius: 6px;
            cursor: pointer;
        }

        .btn-cancel {
            background: #ddd;
        }

        .btn-save {
            background: #b82025;
            color: white;
        }

        .action button {
            cursor: pointer;
        }

        .btn-edit,
        .btn-delete {
            border: none;
            background: transparent;
        }
    </style>
</head>

<body>

<div class="dashboard">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <!-- Logo + Identitas -->
        <div class="profile-admin">

            <div class="logo">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
                     alt="Logo PKS">
            </div>

            <div class="admin-info">
                <h3>ADMIN PKS</h3>
                <p>Ekstrakurikuler pks</p>
                <span>SMKN 2 PURWAKARTA</span>
            </div>

        </div>

        <!-- MENU -->
        <nav class="sidebar-menu">

            <a href="dashboard" class="menu-item">
                <i class="fa-solid fa-house"></i>
                <span>Dashboard</span>
            </a>

            <a href="profil" class="menu-item">
                <i class="fa-regular fa-user"></i>
                <span>Profil</span>
            </a>

            <a href="organisasi" class="menu-item">
                <i class="fa-solid fa-table"></i>
                <span>Organisasi</span>
            </a>

            <a href="berita" class="menu-item">
                <i class="fa-solid fa-newspaper"></i>
                <span>Berita</span>
            </a>

            <a href="galeri" class="menu-item">
                <i class="fa-solid fa-image"></i>
                <span>Galeri</span>
            </a>

            <a href="prestasi" class="menu-item">
                <i class="fa-solid fa-trophy"></i>
                <span>Prestasi</span>
            </a>

            <a href="anggota" class="menu-item">
                <i class="fa-solid fa-users"></i>
                <span>Anggota</span>
            </a>

            <a href="agenda" class="menu-item">
                <i class="fa-regular fa-calendar"></i>
                <span>Agenda</span>
            </a>

            <!-- USER AKTIF -->
            <a href="user" class="menu-item active">
                <i class="fa-solid fa-user-gear"></i>
                <span>User</span>
            </a>

        </nav>

        <!-- LOGOUT -->
        <div class="logout">
            <a href="#">
                <i class="fa-solid fa-arrow-right-from-bracket"></i>
                <span>Logout</span>
            </a>
        </div>

    </aside>


    <!-- ================= MAIN ================= -->
    <main class="main-content">

        <!-- HEADER -->
        <header class="top-header">

            <button class="menu-toggle">
                <i class="fa-solid fa-bars"></i>
            </button>

            <div class="header-right">

                <i class="fa-regular fa-bell notification"></i>

                <div class="user-profile">

                    <i class="fa-solid fa-circle-user"></i>

                    <div>
                        <span>Admin PKS</span>
                        <small>Administrator</small>
                    </div>

                    <i class="fa-solid fa-chevron-down arrow"></i>

                </div>

            </div>

        </header>


        <!-- ================= CONTENT ================= -->
        <section class="content">

            <!-- TITLE -->
            <div class="page-title">
                <h2>Kelola User</h2>
                <p>Kelola data user</p>
            </div>


            <!-- ACTION BAR -->
            <div class="action-bar">

                <button class="btn-add" onclick="bukaTambahUser()">
                    <i class="fa-solid fa-plus"></i>
                    Tambah User
                </button>

                <div class="search-box">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    <input
                        type="text"
                        id="searchInput"
                        placeholder="Cari user..."
                        onkeyup="cariUser()"
                    >

                </div>

            </div>


            <!-- ================= TABLE ================= -->
            <div class="table-container">

                <table>

                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Nama</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>

                    <tbody id="userTable">

                        <!-- DATA USER AKAN MUNCUL DARI JAVASCRIPT -->

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</div>


<!-- ================================================= -->
<!-- MODAL TAMBAH / EDIT USER -->
<!-- ================================================= -->

<div class="modal" id="userModal">

    <div class="modal-content">

        <div class="modal-header">

            <h2 id="modalTitle">Tambah User</h2>

            <button
                class="close-modal"
                onclick="tutupModal()">
                &times;
            </button>

        </div>


        <form id="userForm">

            <div class="form-group">

                <label for="nama">
                    Nama
                </label>

                <input
                    type="text"
                    id="nama"
                    required
                    placeholder="Masukkan nama"
                >

            </div>


            <div class="form-group">

                <label for="username">
                    Username
                </label>

                <input
                    type="text"
                    id="username"
                    required
                    placeholder="Masukkan username"
                >

            </div>


            <div class="form-group">

                <label for="email">
                    Email
                </label>

                <input
                    type="email"
                    id="email"
                    required
                    placeholder="Masukkan email"
                >

            </div>


            <div class="form-group">

                <label for="role">
                    Role
                </label>

                <select id="role" required>

                    <option value="Administrator">
                        Administrator
                    </option>

                    <option value="Viewer">
                        Viewer
                    </option>

                </select>

            </div>


            <div class="modal-buttons">

                <button
                    type="button"
                    class="btn-cancel"
                    onclick="tutupModal()">
                    Batal
                </button>

                <button
                    type="submit"
                    class="btn-save">
                    Simpan
                </button>

            </div>

        </form>

    </div>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    // ================= DATA USER =================

    let users = JSON.parse(localStorage.getItem('usersPKS')) || [

        {
            id: 1,
            nama: 'Admin PKS',
            username: 'Admin',
            email: 'adminpks@gmail.com',
            role: 'Administrator'
        },

        {
            id: 2,
            nama: 'Aainrmaul',
            username: 'airinmaul',
            email: 'aainrmaul@gmail.com',
            role: 'Viewer'
        },

        {
            id: 3,
            nama: 'Aaninw',
            username: 'aaninw',
            email: 'aaninw@gmail.com',
            role: 'Viewer'
        }

    ];


    let editId = null;


    // ================= TAMPILKAN DATA =================

    function tampilkanUser(data = users) {

        const table = document.getElementById('userTable');

        table.innerHTML = '';


        if (data.length === 0) {

            table.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align:center;">
                        Data user tidak ditemukan
                    </td>
                </tr>
            `;

            return;
        }


        data.forEach((user, index) => {

            table.innerHTML += `

                <tr>

                    <td>${index + 1}.</td>

                    <td>${user.nama}</td>

                    <td>${user.username}</td>

                    <td>${user.email}</td>

                    <td>${user.role}</td>

                    <td class="action">

                        <button
                            class="btn-edit"
                            onclick="editUser(${user.id})"
                            title="Ubah">

                            <i class="fa-solid fa-pen"></i>

                        </button>


                        <button
                            class="btn-delete"
                            onclick="hapusUser(${user.id})"
                            title="Hapus">

                            <i class="fa-solid fa-trash"></i>

                        </button>

                    </td>

                </tr>

            `;

        });

    }


    // ================= TAMBAH USER =================

    function bukaTambahUser() {

        editId = null;

        document.getElementById('modalTitle').textContent =
            'Tambah User';

        document.getElementById('userForm').reset();

        document.getElementById('userModal')
            .classList.add('show');

    }


    // ================= EDIT USER =================

    function editUser(id) {

        const user = users.find(u => u.id === id);

        if (!user) return;


        editId = id;


        document.getElementById('modalTitle').textContent =
            'Ubah User';


        document.getElementById('nama').value =
            user.nama;

        document.getElementById('username').value =
            user.username;

        document.getElementById('email').value =
            user.email;

        document.getElementById('role').value =
            user.role;


        document.getElementById('userModal')
            .classList.add('show');

    }


    // ================= SIMPAN USER =================

    document.getElementById('userForm')
        .addEventListener('submit', function(event) {

            event.preventDefault();


            const nama =
                document.getElementById('nama').value;

            const username =
                document.getElementById('username').value;

            const email =
                document.getElementById('email').value;

            const role =
                document.getElementById('role').value;


            // JIKA EDIT

            if (editId !== null) {

                const user = users.find(
                    u => u.id === editId
                );

                user.nama = nama;
                user.username = username;
                user.email = email;
                user.role = role;

            }


            // JIKA TAMBAH

            else {

                const newUser = {

                    id: Date.now(),

                    nama: nama,

                    username: username,

                    email: email,

                    role: role

                };


                users.push(newUser);

            }


            simpanData();

            tampilkanUser();

            tutupModal();

        });


    // ================= HAPUS USER =================

    function hapusUser(id) {

        const user = users.find(
            u => u.id === id
        );


        if (!user) return;


        const yakin = confirm(
            'Yakin ingin menghapus user "' +
            user.nama +
            '"?'
        );


        if (!yakin) return;


        users = users.filter(
            u => u.id !== id
        );


        simpanData();

        tampilkanUser();

    }


    // ================= SIMPAN LOCAL STORAGE =================

    function simpanData() {

        localStorage.setItem(
            'usersPKS',
            JSON.stringify(users)
        );

    }


    // ================= TUTUP MODAL =================

    function tutupModal() {

        document.getElementById('userModal')
            .classList.remove('show');

        editId = null;

    }


    // ================= SEARCH =================

    function cariUser() {

        const keyword =
            document.getElementById('searchInput')
                .value
                .toLowerCase();


        const hasil = users.filter(user =>

            user.nama.toLowerCase()
                .includes(keyword)

            ||

            user.username.toLowerCase()
                .includes(keyword)

            ||

            user.email.toLowerCase()
                .includes(keyword)

            ||

            user.role.toLowerCase()
                .includes(keyword)

        );


        tampilkanUser(hasil);

    }


    // ================= SIDEBAR =================

    const menuToggle =
        document.querySelector('.menu-toggle');

    const sidebar =
        document.querySelector('.sidebar');


    menuToggle.addEventListener(
        'click',
        function() {

            sidebar.classList.toggle('show');

        }
    );


    // ================= JALANKAN SAAT HALAMAN DIBUKA =================

    tampilkanUser();

</script>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backenduser.blade.php ENDPATH**/ ?>