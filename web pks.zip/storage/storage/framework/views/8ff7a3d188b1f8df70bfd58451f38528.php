<?php $__env->startSection('title', $berita->judul); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-hero">
        <img class="page-hero__bg" src="<?php echo e(asset($berita->gambar ?: ($profil->foto_header ?: 'img/POTO PKS3.jpeg'))); ?>" alt="">

        <div class="container">
            <div class="breadcrumb">
                <a href="<?php echo e(route('beranda')); ?>">Beranda</a> /
                <a href="<?php echo e(route('berita.index')); ?>">Berita</a> /
                <span><?php echo e(\Illuminate\Support\Str::limit($berita->judul, 40)); ?></span>
            </div>

            <h1><?php echo e($berita->judul); ?></h1>
        </div>
    </section>

    <section class="section">
        <div class="container" style="max-width:840px;">

            <article class="article">

                <?php if($berita->gambar): ?>
                    <img src="<?php echo e(asset($berita->gambar)); ?>" alt="<?php echo e($berita->judul); ?>" class="article__cover">
                <?php endif; ?>

                <div class="article__meta">
                    <span class="chip chip--navy"><?php echo e($berita->kategori); ?></span>
                    <span>📅 <?php echo e($berita->tanggal?->translatedFormat('d F Y')); ?></span>
                    <span>✍️ <?php echo e($berita->penulis); ?></span>
                </div>

                <div class="article__body">
                    <?php $__currentLoopData = preg_split('/\r\n|\r|\n/', (string) $berita->isi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paragraf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(trim($paragraf) !== ''): ?>
                            <p><?php echo e($paragraf); ?></p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            </article>

            <div style="margin-top:1.6rem;">
                <a href="<?php echo e(route('berita.index')); ?>" class="btn btn--outline">← Kembali ke Daftar Berita</a>
            </div>

            <?php if($lainnya->isNotEmpty()): ?>
                <div class="section-head section-head--left" style="margin-top:3rem;">
                    <h2 style="font-size:1.25rem;">Berita Lainnya</h2>
                </div>

                <div class="grid grid--3">
                    <?php $__currentLoopData = $lainnya; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-berita', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/berita-detail.blade.php ENDPATH**/ ?>