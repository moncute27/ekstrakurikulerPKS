<?php $__env->startSection('title', 'Profil Ekskul'); ?>
<?php $__env->startSection('subtitle', 'Data ini tampil di halaman Profil, footer, dan header website'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Profil Ekstrakurikuler</h1>
            <p>Ubah identitas, visi, misi, serta kontak yang ditampilkan di website.</p>
        </div>

        <a href="<?php echo e(route('profil')); ?>" target="_blank" class="btn btn--light">Lihat Halaman ↗</a>
    </div>

    <form method="POST" action="<?php echo e(route('admin.profil.update')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="panel" style="margin-bottom:1.2rem;">
            <div class="panel__head"><h3>Identitas</h3></div>
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field <?php $__errorArgs = ['nama_ekskul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nama_ekskul">Nama Ekstrakurikuler <span class="req">*</span></label>
                        <input type="text" id="nama_ekskul" name="nama_ekskul" value="<?php echo e(old('nama_ekskul', $detail->nama_ekskul)); ?>" required>
                        <?php $__errorArgs = ['nama_ekskul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="nama_sekolah">Nama Sekolah <span class="req">*</span></label>
                        <input type="text" id="nama_sekolah" name="nama_sekolah" value="<?php echo e(old('nama_sekolah', $detail->nama_sekolah)); ?>" required>
                        <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field field--full">
                        <label for="deskripsi_singkat">Deskripsi Singkat</label>
                        <textarea id="deskripsi_singkat" name="deskripsi_singkat" rows="3"><?php echo e(old('deskripsi_singkat', $detail->deskripsi_singkat)); ?></textarea>
                        <span class="hint">Tampil di bawah judul halaman Profil dan di footer.</span>
                    </div>

                </div>
            </div>
        </div>

        <div class="panel" style="margin-bottom:1.2rem;">
            <div class="panel__head"><h3>Sejarah, Visi &amp; Misi</h3></div>
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field field--full">
                        <label for="sejarah">Sejarah / Tentang Kami</label>
                        <textarea id="sejarah" name="sejarah" rows="6"><?php echo e(old('sejarah', $detail->sejarah)); ?></textarea>
                        <span class="hint">Pisahkan tiap paragraf dengan baris baru.</span>
                    </div>

                    <div class="field field--full">
                        <label for="visi">Visi</label>
                        <textarea id="visi" name="visi" rows="3"><?php echo e(old('visi', $detail->visi)); ?></textarea>
                    </div>

                    <div class="field field--full">
                        <label for="misi">Misi</label>
                        <textarea id="misi" name="misi" rows="6"><?php echo e(old('misi', $detail->misi)); ?></textarea>
                        <span class="hint">Tulis satu poin misi per baris.</span>
                    </div>

                </div>
            </div>
        </div>

        <div class="panel" style="margin-bottom:1.2rem;">
            <div class="panel__head"><h3>Kontak</h3></div>
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field field--full">
                        <label for="alamat">Alamat</label>
                        <input type="text" id="alamat" name="alamat" value="<?php echo e(old('alamat', $detail->alamat)); ?>">
                    </div>

                    <div class="field <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e(old('email', $detail->email)); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field">
                        <label for="telepon">Telepon</label>
                        <input type="text" id="telepon" name="telepon" value="<?php echo e(old('telepon', $detail->telepon)); ?>">
                    </div>

                    <div class="field">
                        <label for="instagram">Instagram</label>
                        <input type="text" id="instagram" name="instagram" value="<?php echo e(old('instagram', $detail->instagram)); ?>" placeholder="@pks.smkn2purwakarta">
                    </div>

                </div>
            </div>
        </div>

        <div class="panel">
            <div class="panel__head"><h3>Gambar</h3></div>
            <div class="panel__body">
                <div class="form-grid">

                    <div class="field <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="logo">Logo</label>
                        <input type="file" id="logo" name="logo" accept="image/*" data-preview="#previewLogo">
                        <span class="hint">Format JPG/PNG/WEBP, maksimal 2 MB. Kosongkan bila tidak ingin mengganti.</span>
                        <div class="preview">
                            <img id="previewLogo" src="<?php echo e(asset($detail->logo ?: 'img/logo pks.jpeg')); ?>" alt="">
                        </div>
                        <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field <?php $__errorArgs = ['foto_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="foto_header">Foto Header</label>
                        <input type="file" id="foto_header" name="foto_header" accept="image/*" data-preview="#previewHeader">
                        <span class="hint">Gambar latar untuk hero beranda dan header halaman. Maksimal 4 MB.</span>
                        <div class="preview">
                            <img id="previewHeader" src="<?php echo e(asset($detail->foto_header ?: 'img/POTO PKS3.jpeg')); ?>" alt="">
                        </div>
                        <?php $__errorArgs = ['foto_header'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><span class="error"><?php echo e($message); ?></span><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>

                <div class="form-actions">
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn--light">Batal</a>
                    <button type="submit" class="btn btn--primary">Simpan Perubahan</button>
                </div>
            </div>
        </div>

    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/profil.blade.php ENDPATH**/ ?>