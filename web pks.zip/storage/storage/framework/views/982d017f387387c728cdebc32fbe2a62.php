<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Struktur Organisasi - PKS</title>

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="organisasi.css">
</head>

<body>

    <div class="page">

        <!-- ================= HEADER ================= -->
        <header class="header">

            <!-- Foto header -->
            <img src="img/POTO PKS3.jpeg"
                 alt="Kegiatan PKS"
                 class="header-image">

            <!-- Logo -->
            <img src="img/logo pks.jpeg"
                 alt="Logo PKS"
                 class="logo">

            <!-- Navbar -->
            <nav class="navbar">

                <a href="beranda">Beranda</a>
                <a href="profil">Profil</a>

                <a href="organisasi" class="active">
                    Organisasi
                </a>

                <a href="berita">Berita</a>
                <a href="galeri">Galeri</a>
                <a href="prestasi">Prestasi</a>
                <a href="anggota">Anggota</a>
                <a href="agenda">Agenda</a>
                <a href="user">user</a>

            </nav>

        </header>


        <!-- ================= ORGANISASI ================= -->
        <main class="organization">

            <h1>STRUKTUR ORGANISASI</h1>

            <div class="title-line"></div>


            <!-- ================= BARIS PERTAMA ================= -->
            <div class="top-members">

                <!-- PEMBINA -->
                <div class="member-card">

                    <img src="img/pembina.jpeg"
                         alt="Pembina"
                         class="member-photo">

                    <div class="member-info">
                        <span>Lilis Aisyah Yuniarti, S.Pd.</span>
                        <strong>Pembina</strong>
                    </div>

                </div>


                <!-- PELATIH -->
                <div class="member-card">

                    <img src="img/pelatih.jpeg"
                         alt="Pelatih"
                         class="member-photo">

                    <div class="member-info">
                        <span>Lutfiah Aprilina</span>
                        <strong>Pelatih</strong>
                    </div>

                </div>


                <!-- KETUA -->
                <div class="member-card">

                    <div class="default-icon">
                        <i class="fa-regular fa-user"></i>
                    </div>

                    <div class="member-info">
                        <span>Natasya</span>
                        <strong>Ketua</strong>
                    </div>

                </div>

            </div>


            <!-- ================= KOLOM PENGURUS ================= -->
            <div class="organization-columns">

                <!-- KOLOM KIRI -->
                <div class="column">

                    <!-- WAKIL KETUA -->
                    <div class="member-card">

                        <div class="default-icon">
                            <i class="fa-regular fa-user"></i>
                        </div>

                        <div class="member-info">
                            <span>Aini Almaulida</span>
                            <strong>Wakil Ketua</strong>
                        </div>

                    </div>


                    <!-- SEKRETARIS -->
                    <div class="member-card">

                        <div class="default-icon">
                            <i class="fa-regular fa-user"></i>
                        </div>

                        <div class="member-info">
                            <span>Esa Maesyaroh</span>
                            <strong>Sekretaris</strong>
                        </div>

                    </div>

                </div>


                <!-- KOLOM KANAN -->
                <div class="column">

                    <!-- BENDAHARA -->
                    <div class="member-card">

                        <div class="default-icon">
                            <i class="fa-regular fa-user"></i>
                        </div>

                        <div class="member-info">
                            <span>Devi Nurwati</span>
                            <strong>Bendahara</strong>
                        </div>

                    </div>


                    <!-- HUMAS -->
                    <div class="member-card">

                        <div class="default-icon">
                            <i class="fa-regular fa-user"></i>
                        </div>

                        <div class="member-info">
                            <span>Revita Maulida</span>
                            <strong>Humas</strong>
                        </div>

                    </div>

                </div>

            </div>

        </main>

    </div>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/organisasi.blade.php ENDPATH**/ ?>