<?php $__env->startSection('title', 'Kelola Berita'); ?>
<?php $__env->startSection('subtitle', 'Semua berita dan informasi kegiatan PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Kelola Berita</h1>
            <p>Total <?php echo e($berita->total()); ?> berita tersimpan di database.</p>
        </div>

        <a href="<?php echo e(route('admin.berita.create')); ?>" class="btn btn--gold">+ Tambah Berita</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.berita.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari judul atau penulis...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.berita.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($berita->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">📰</div>
                <p>Belum ada berita. Klik "Tambah Berita" untuk membuat yang pertama.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th style="width:80px;">Foto</th>
                            <th>Judul</th>
                            <th>Kategori</th>
                            <th>Tanggal</th>
                            <th>Penulis</th>
                            <th>Status</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $berita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if($item->gambar): ?>
                                        <img src="<?php echo e(asset($item->gambar)); ?>" alt="" class="thumb">
                                    <?php else: ?>
                                        <span class="thumb-empty">📰</span>
                                    <?php endif; ?>
                                </td>
                                <td class="cell-title" style="max-width:320px;">
                                    <strong><?php echo e($item->judul); ?></strong>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($item->ringkasan, 70)); ?></small>
                                </td>
                                <td><span class="badge badge--navy"><?php echo e($item->kategori); ?></span></td>
                                <td><?php echo e($item->tanggal?->translatedFormat('d M Y')); ?></td>
                                <td><?php echo e($item->penulis); ?></td>
                                <td>
                                    <span class="badge <?php echo e($item->is_published ? 'badge--green' : 'badge--grey'); ?>">
                                        <?php echo e($item->is_published ? 'Terbit' : 'Draf'); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="td-actions">
                                        <?php if($item->is_published): ?>
                                            <a href="<?php echo e(route('berita.show', $item)); ?>" target="_blank" class="btn btn--light btn-icon" title="Lihat">👁</a>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('admin.berita.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <form method="POST" action="<?php echo e(route('admin.berita.destroy', $item)); ?>"
                                              data-confirm="Hapus berita &quot;<?php echo e($item->judul); ?>&quot;?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($berita->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/berita/index.blade.php ENDPATH**/ ?>