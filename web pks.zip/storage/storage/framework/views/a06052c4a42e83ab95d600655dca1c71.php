<?php if($paginator->hasPages()): ?>
    <nav class="pager" role="navigation" aria-label="Navigasi halaman">

        
        <?php if($paginator->onFirstPage()): ?>
            <span class="pager__item is-disabled">‹ Sebelumnya</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pager__item" rel="prev">‹ Sebelumnya</a>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(is_string($element)): ?>
                <span class="pager__item is-disabled"><?php echo e($element); ?></span>
            <?php endif; ?>

            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <span class="pager__item is-active" aria-current="page"><?php echo e($page); ?></span>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>" class="pager__item"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pager__item" rel="next">Berikutnya ›</a>
        <?php else: ?>
            <span class="pager__item is-disabled">Berikutnya ›</span>
        <?php endif; ?>

    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/vendor/pagination/pks.blade.php ENDPATH**/ ?>