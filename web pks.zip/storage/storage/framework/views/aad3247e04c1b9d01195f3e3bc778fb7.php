<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Agenda - Admin PKS</title>

    <!-- Font Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backendagenda.css')); ?>">
</head>

<body>

<div class="admin-container">

    <!-- =================================================
         SIDEBAR
    ================================================== -->

    <aside class="sidebar">

        <!-- Logo + Identitas -->
        <div class="brand">

            <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
                 alt="Logo PKS"
                 class="brand-logo">

            <div class="brand-text">
                <h2>ADMIN PKS</h2>
                <p>Ekstrakurikuler pks</p>
                <p>SMKN 2 PURWAKARTA</p>
            </div>

        </div>


        <!-- Menu -->
        <nav class="sidebar-menu">

            <a href="/dashboard">
                <i class="fa-solid fa-house"></i>
                <span>Dashboard</span>
            </a>

            <a href="/backendprofil">
                <i class="fa-regular fa-user"></i>
                <span>Profil</span>
            </a>

            <a href="/backendorganisasi">
                <i class="fa-solid fa-table-cells-large"></i>
                <span>Organisasi</span>
            </a>

            <a href="/backendberita">
                <i class="fa-solid fa-newspaper"></i>
                <span>Berita</span>
            </a>

            <a href="/backendgaleri">
                <i class="fa-regular fa-image"></i>
                <span>Galeri</span>
            </a>

            <a href="/backendprestasi">
                <i class="fa-solid fa-trophy"></i>
                <span>Prestasi</span>
            </a>

            <a href="/backendanggota">
                <i class="fa-solid fa-user-group"></i>
                <span>Anggota</span>
            </a>

            <!-- Aktif -->
            <a href="/backendagenda" class="active">
                <i class="fa-regular fa-calendar"></i>
                <span>Agenda</span>
            </a>

            <a href="/backenduser">
                <i class="fa-solid fa-user-gear"></i>
                <span>User</span>
            </a>

        </nav>


        <!-- Logout -->
        <div class="logout">

            <a href="logout">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- =================================================
         MAIN CONTENT
    ================================================== -->

    <main class="main-content">

        <!-- TOP BAR -->

        <header class="topbar">

            <!-- Hamburger -->
            <button class="menu-button">
                <i class="fa-solid fa-bars"></i>
            </button>


            <!-- Bagian kanan -->
            <div class="topbar-right">

                <!-- Notification -->
                <button class="notification">
                    <i class="fa-solid fa-bell"></i>
                </button>


                <!-- Admin -->
                <div class="admin-profile">

                    <div class="admin-icon">
                        <i class="fa-regular fa-circle-user"></i>
                    </div>

                    <div class="admin-name">
                        <span>Admin PKS</span>
                        <small>Administrator</small>
                    </div>

                    <i class="fa-solid fa-chevron-down arrow"></i>

                </div>

            </div>

        </header>


        <!-- =================================================
             CONTENT
        ================================================== -->

        <section class="content">

            <!-- Judul -->
            <div class="page-title">

                <h1>Kelola Agenda</h1>

                <p>
                    Kelola data agenda kegiatan PKS.
                </p>

            </div>


            <!-- Toolbar -->
            <div class="toolbar">

                <!-- Tambah -->
                <button class="add-button">
                    <i class="fa-solid fa-plus"></i>
                    Tambah Agenda
                </button>


                <!-- Search -->
                <div class="search-box">

                    <i class="fa-solid fa-magnifying-glass"></i>

                    <input
                        type="text"
                        placeholder="Cari agenda..."
                    >

                </div>

            </div>


            <!-- =================================================
                 TABLE
            ================================================== -->

            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>
                            <th class="number">No.</th>
                            <th>Nama Kegiatan</th>
                            <th>Deskripsi</th>
                            <th class="action-column">Aksi</th>
                        </tr>

                    </thead>


                    <tbody>

                        <!-- DATA 1 -->

                        <tr>

                            <td class="number">1.</td>

                            <td>
                                Peringatan hut
                                <br>
                                bhayangkara ke-81
                            </td>

                            <td>
                                Kegiatan dalam rangka
                                memperingati HUT Bhayangkara
                                ke-81
                            </td>

                            <td class="actions">

                                <button class="edit">
                                    <i class="fa-solid fa-pen"></i>
                                </button>

                                <button class="delete">
                                    <i class="fa-regular fa-trash-can"></i>
                                </button>

                            </td>

                        </tr>


                        <!-- DATA 2 -->

                        <tr>

                            <td class="number">2.</td>

                            <td>
                                Serah terima
                                <br>
                                jabatan
                            </td>

                            <td>
                                Kegiatan serah terima jabatan
                                pengurus ekstrakurikuler PKS
                            </td>

                            <td class="actions">

                                <button class="edit">
                                    <i class="fa-solid fa-pen"></i>
                                </button>

                                <button class="delete">
                                    <i class="fa-regular fa-trash-can"></i>
                                </button>

                            </td>

                        </tr>


                        <!-- DATA 3 -->

                        <tr>

                            <td class="number">3.</td>

                            <td>
                                Demo ekstrakurikuler
                                <br>
                                PKS
                            </td>

                            <td>
                                Kegiatan pengenalan
                                ekstrakurikuler PKS kepada
                                siswa
                            </td>

                            <td class="actions">

                                <button class="edit">
                                    <i class="fa-solid fa-pen"></i>
                                </button>

                                <button class="delete">
                                    <i class="fa-regular fa-trash-can"></i>
                                </button>

                            </td>

                        </tr>

                    </tbody>

                </table>

            </div>

        </section>

    </main>

</div>


<!-- =================================================
     JAVASCRIPT SIDEBAR MOBILE
================================================== -->

<script>

    const menuButton = document.querySelector('.menu-button');
    const sidebar = document.querySelector('.sidebar');

    menuButton.addEventListener('click', function () {
        sidebar.classList.toggle('show');
    });

</script>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backendagenda.blade.php ENDPATH**/ ?>