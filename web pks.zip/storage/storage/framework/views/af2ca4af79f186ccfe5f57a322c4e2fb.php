<?php $__env->startSection('title', 'Kelola Prestasi'); ?>
<?php $__env->startSection('subtitle', 'Pencapaian Ekstrakurikuler PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Kelola Prestasi</h1>
            <p>Total <?php echo e($prestasi->total()); ?> prestasi tersimpan.</p>
        </div>

        <a href="<?php echo e(route('admin.prestasi.create')); ?>" class="btn btn--gold">+ Tambah Prestasi</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.prestasi.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari judul prestasi...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.prestasi.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($prestasi->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">🏆</div>
                <p>Belum ada data prestasi.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th>Prestasi</th>
                            <th>Tingkat</th>
                            <th>Tahun</th>
                            <th>Penyelenggara</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $prestasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="cell-title" style="max-width:340px;">
                                    <strong>🏆 <?php echo e($item->judul); ?></strong>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($item->keterangan, 70)); ?></small>
                                </td>
                                <td><span class="badge badge--gold"><?php echo e($item->tingkat); ?></span></td>
                                <td><?php echo e($item->tahun ?: '—'); ?></td>
                                <td><?php echo e($item->penyelenggara ?: '—'); ?></td>
                                <td>
                                    <div class="td-actions">
                                        <a href="<?php echo e(route('admin.prestasi.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <form method="POST" action="<?php echo e(route('admin.prestasi.destroy', $item)); ?>"
                                              data-confirm="Hapus prestasi &quot;<?php echo e($item->judul); ?>&quot;?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($prestasi->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/prestasi/index.blade.php ENDPATH**/ ?>