<?php if(session('sukses')): ?>
    <div class="alert alert--success">
        <span>✅</span>
        <div><?php echo e(session('sukses')); ?></div>
    </div>
<?php endif; ?>

<?php if($errors->any()): ?>
    <div class="alert alert--danger">
        <span>⚠️</span>
        <div>
            <strong>Terjadi kesalahan, periksa kembali isian Anda.</strong>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($pesan); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/partials/flash.blade.php ENDPATH**/ ?>