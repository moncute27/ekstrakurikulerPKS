<?php $__env->startSection('title', 'Anggota'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Daftar Anggota',
        'sub' => 'Anggota aktif Ekstrakurikuler PKS dari berbagai angkatan.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <form class="search-form" method="GET" action="<?php echo e(route('anggota')); ?>">
                <input type="text" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari nama atau kelas...">

                <select name="angkatan">
                    <option value="">Semua Angkatan</option>
                    <?php $__currentLoopData = $daftarAngkatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item); ?>" <?php if($angkatan == $item): echo 'selected'; endif; ?>>Angkatan <?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <button type="submit" class="btn btn--outline">Cari</button>
            </form>

            <?php if($anggota->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">👥</div>
                    <p>Data anggota tidak ditemukan.</p>
                </div>
            <?php else: ?>
                <div class="table-wrap">
                    <div class="table-scroll">
                        <table class="data">
                            <thead>
                                <tr>
                                    <th style="width:60px;">No</th>
                                    <th>Nama</th>
                                    <th>Kelas</th>
                                    <th>Jabatan</th>
                                    <th>Angkatan</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($anggota->firstItem() + $i); ?></td>
                                        <td>
                                            <div class="cell-user">
                                                <?php if($item->foto): ?>
                                                    <img src="<?php echo e(asset($item->foto)); ?>" alt="" class="avatar-sm">
                                                <?php else: ?>
                                                    <span class="avatar-initial"><?php echo e(strtoupper(substr($item->nama, 0, 1))); ?></span>
                                                <?php endif; ?>
                                                <strong><?php echo e($item->nama); ?></strong>
                                            </div>
                                        </td>
                                        <td><?php echo e($item->kelas); ?></td>
                                        <td><?php echo e($item->jabatan); ?></td>
                                        <td><?php echo e($item->angkatan); ?></td>
                                        <td>
                                            <span class="chip <?php echo e($item->status === 'Aktif' ? 'chip--green' : 'chip--grey'); ?>">
                                                <?php echo e($item->status); ?>

                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="pagination-wrap"><?php echo e($anggota->links()); ?></div>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/anggota.blade.php ENDPATH**/ ?>