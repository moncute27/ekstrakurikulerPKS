<?php $__env->startSection('title', 'Manajemen User'); ?>
<?php $__env->startSection('subtitle', 'Akun yang dapat mengakses panel admin'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Manajemen User</h1>
            <p>Total <?php echo e($users->total()); ?> akun terdaftar.</p>
        </div>

        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn--gold">+ Tambah User</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.user.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari nama atau email...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($users->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">🔑</div>
                <p>Tidak ada akun yang cocok.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Email</th>
                            <th>Peran</th>
                            <th>Dibuat</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div style="display:flex;align-items:center;gap:.7rem;">
                                        <?php if($item->foto): ?>
                                            <img src="<?php echo e(asset($item->foto)); ?>" alt="" class="thumb thumb--round">
                                        <?php else: ?>
                                            <span class="thumb-empty" style="width:40px;border-radius:50%;">
                                                <?php echo e(strtoupper(substr($item->name, 0, 1))); ?>

                                            </span>
                                        <?php endif; ?>
                                        <strong>
                                            <?php echo e($item->name); ?>

                                            <?php if($item->id === auth()->id()): ?>
                                                <span class="badge badge--navy">Anda</span>
                                            <?php endif; ?>
                                        </strong>
                                    </div>
                                </td>
                                <td><?php echo e($item->email); ?></td>
                                <td>
                                    <span class="badge <?php echo e($item->role === 'admin' ? 'badge--gold' : ($item->role === 'pengurus' ? 'badge--navy' : 'badge--grey')); ?>">
                                        <?php echo e(ucfirst($item->role)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($item->created_at?->translatedFormat('d M Y')); ?></td>
                                <td>
                                    <div class="td-actions">
                                        <a href="<?php echo e(route('admin.user.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <?php if($item->id !== auth()->id()): ?>
                                            <form method="POST" action="<?php echo e(route('admin.user.destroy', $item)); ?>"
                                                  data-confirm="Hapus akun &quot;<?php echo e($item->name); ?>&quot;?">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($users->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/user/index.blade.php ENDPATH**/ ?>