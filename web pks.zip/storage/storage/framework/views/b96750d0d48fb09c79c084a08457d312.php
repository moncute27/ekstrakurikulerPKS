<?php $__env->startSection('title', 'Galeri'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Galeri Kegiatan',
        'sub' => 'Dokumentasi berbagai kegiatan Ekstrakurikuler PKS.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <?php if($galeri->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">🖼️</div>
                    <p>Belum ada foto dalam galeri.</p>
                </div>
            <?php else: ?>
                <div class="gallery" id="gallery">
                    <?php $__currentLoopData = $galeri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <figure data-src="<?php echo e(asset($foto->gambar)); ?>" data-caption="<?php echo e($foto->keterangan ?: $foto->judul); ?>">
                            <img src="<?php echo e(asset($foto->gambar)); ?>" alt="<?php echo e($foto->judul); ?>" loading="lazy">
                            <figcaption><?php echo e($foto->judul); ?></figcaption>
                        </figure>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="pagination-wrap"><?php echo e($galeri->links()); ?></div>
            <?php endif; ?>

        </div>
    </section>

    <div class="lightbox" id="lightbox">
        <button class="lightbox__close" id="lightboxClose" type="button" aria-label="Tutup">×</button>
        <img id="lightboxImage" src="" alt="">
        <div class="lightbox__caption" id="lightboxCaption"></div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function () {
        const lightbox = document.getElementById('lightbox');
        const gambar = document.getElementById('lightboxImage');
        const caption = document.getElementById('lightboxCaption');

        document.querySelectorAll('#gallery figure').forEach(function (figure) {
            figure.addEventListener('click', function () {
                gambar.src = figure.dataset.src;
                caption.textContent = figure.dataset.caption || '';
                lightbox.classList.add('is-open');
            });
        });

        function tutup() {
            lightbox.classList.remove('is-open');
        }

        document.getElementById('lightboxClose').addEventListener('click', tutup);
        lightbox.addEventListener('click', e => { if (e.target === lightbox) tutup(); });
        document.addEventListener('keydown', e => { if (e.key === 'Escape') tutup(); });
    })();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/galeri.blade.php ENDPATH**/ ?>