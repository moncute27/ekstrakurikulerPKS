<?php $__env->startSection('title', 'Struktur Organisasi'); ?>
<?php $__env->startSection('subtitle', 'Kelola data pembina, pelatih, dan pengurus'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Struktur Organisasi</h1>
            <p>Total <?php echo e($pengurus->total()); ?> data pengurus tersimpan.</p>
        </div>

        <a href="<?php echo e(route('admin.pengurus.create')); ?>" class="btn btn--gold">+ Tambah Pengurus</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.pengurus.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari nama atau jabatan...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.pengurus.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($pengurus->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">🎖️</div>
                <p>Belum ada data pengurus.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th style="width:70px;">Urutan</th>
                            <th style="width:70px;">Foto</th>
                            <th>Nama</th>
                            <th>Jabatan</th>
                            <th>Periode</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $pengurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><span class="badge badge--navy"><?php echo e($item->urutan); ?></span></td>
                                <td>
                                    <?php if($item->foto): ?>
                                        <img src="<?php echo e(asset($item->foto)); ?>" alt="" class="thumb thumb--round">
                                    <?php else: ?>
                                        <span class="thumb-empty" style="width:40px;border-radius:50%;">👤</span>
                                    <?php endif; ?>
                                </td>
                                <td><strong><?php echo e($item->nama); ?></strong></td>
                                <td><?php echo e($item->jabatan); ?></td>
                                <td><?php echo e($item->periode ?: '—'); ?></td>
                                <td>
                                    <div class="td-actions">
                                        <a href="<?php echo e(route('admin.pengurus.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <form method="POST" action="<?php echo e(route('admin.pengurus.destroy', $item)); ?>"
                                              data-confirm="Hapus data pengurus &quot;<?php echo e($item->nama); ?>&quot;?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($pengurus->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/pengurus/index.blade.php ENDPATH**/ ?>