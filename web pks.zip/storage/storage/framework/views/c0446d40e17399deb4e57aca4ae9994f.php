<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Ekstrakurikuler PKS SMKN 2 Purwakarta</title>

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Icon -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="profil.css">
</head>

<body>

    <main class="page">

        <!-- ================= HEADER ================= -->
        <header class="header">

            <img src="img/POTO PKS3.jpeg"
                 alt="Kegiatan PKS"
                 class="header-image">

            <!-- Logo -->
            <img src="img/logo pks.jpeg"
                 alt="Logo PKS"
                 class="logo">

            <!-- Navbar -->
            <nav class="navbar">

                <a href="beranda">Beranda</a>
                <a href="profil" class="active">Profil</a>
                <a href="organisasi">Organisasi</a>
                <a href="berita">Berita</a>
                <a href="galeri">Galeri</a>
                <a href="prestasi">Prestasi</a>
                <a href="anggota">Anggota</a>
                <a href="agenda">Agenda</a>
                <a href="user">user</a>

            </nav>

        </header>


        <!-- ================= PROFIL ================= -->
        <section class="profile">

            <h1>
                EKSTRAKURIKULER PKS<br>
                SMKN 2 PURWAKARTA
            </h1>

            <p class="description">
                Patroli Keamanan Sekolah (PKS) merupakan organisasi
                ekstrakurikuler di sekolah yang bertujuan membina
                karakter, kepemimpinan, dan kedisiplinan siswa.
            </p>


            <!-- ================= INFO ================= -->
            <div class="info-container">

                <!-- Sekolah -->
                <div class="info-box">

                    <div class="icon">
                        <i class="fa-solid fa-location-dot"></i>
                    </div>

                    <div>
                        <span>Sekolah</span>
                        <p>SMKN 2 PURWAKARTA</p>
                    </div>

                </div>


                <!-- Ekstrakurikuler -->
                <div class="info-box">

                    <div class="icon">
                        <i class="fa-solid fa-users"></i>
                    </div>

                    <div>
                        <span>EKSTRAKULIKULER</span>
                        <p>PKS</p>
                    </div>

                </div>

            </div>

        </section>

    </main>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/profil.blade.php ENDPATH**/ ?>