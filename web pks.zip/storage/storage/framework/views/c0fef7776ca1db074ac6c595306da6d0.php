<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ekstrakurikuler PKS SMKN 2 Purwakarta</title>

    <link rel="stylesheet" href="<?php echo e(asset('beranda.css')); ?>">
</head>

<body>

    <main class="hero">

        <img
            class="background-photo"
            src="<?php echo e(asset('img/poto pkss.jpg')); ?>"
            alt="Kegiatan Ekstrakurikuler PKS"
        >

        <div class="overlay"></div>

        <header class="navbar">

            <a href="<?php echo e(url('/beranda')); ?>" class="logo">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
            </a>

            <nav class="nav-menu" id="navMenu">
                <a href="<?php echo e(url('/beranda')); ?>" class="active">Beranda</a>
                <a href="<?php echo e(url('/profil')); ?>">Profil</a>
                <a href="<?php echo e(url('/organisasi')); ?>">Organisasi</a>
                <a href="<?php echo e(url('/berita')); ?>">Berita</a>
                <a href="<?php echo e(url('/galeri')); ?>">Galeri</a>
                <a href="<?php echo e(url('/prestasi')); ?>">Prestasi</a>
                <a href="<?php echo e(url('/anggota')); ?>">Anggota</a>
                <a href="<?php echo e(url('/agenda')); ?>">Agenda</a>
                <a href="<?php echo e(url('/user')); ?>">User</a>
            </nav>

            <button class="menu-toggle" id="menuToggle" type="button">
                ☰
            </button>

        </header>

        <section class="hero-content">
            <h1>
                EKSTRAKURIKULER PKS<br>
                SMKN 2 PURWAKARTA
            </h1>

            <p>
                Membentuk siswa yang disiplin, bertanggung jawab,
                dan berkarakter melalui kegiatan Patroli Keamanan Sekolah.
            </p>
        </section>

    </main>

    <script>
        const menuToggle = document.getElementById("menuToggle");
        const navMenu = document.getElementById("navMenu");

        menuToggle.addEventListener("click", function () {
            navMenu.classList.toggle("show");
        });

        const navLinks = document.querySelectorAll(".nav-menu a");

        navLinks.forEach(function (link) {
            link.addEventListener("click", function () {
                navMenu.classList.remove("show");
            });
        });
    </script>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/beranda.blade.php ENDPATH**/ ?>