<?php $__env->startSection('title', 'Agenda'); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.page-hero', [
        'judul' => 'Agenda Kegiatan',
        'sub' => 'Jadwal kegiatan Ekstrakurikuler PKS yang akan dan telah dilaksanakan.',
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <section class="section">
        <div class="container">

            <div class="section-head section-head--left">
                <div class="section-head__eyebrow">Mendatang</div>
                <h2>Kegiatan Yang Akan Datang</h2>
            </div>

            <?php if($mendatang->isEmpty()): ?>
                <div class="empty">
                    <div class="empty__icon">📅</div>
                    <p>Belum ada agenda mendatang yang dijadwalkan.</p>
                </div>
            <?php else: ?>
                <div class="grid" style="gap:1rem;">
                    <?php $__currentLoopData = $mendatang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-agenda', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <?php if($lampau->isNotEmpty()): ?>
                <div class="section-head section-head--left" style="margin-top:3rem;">
                    <div class="section-head__eyebrow">Arsip</div>
                    <h2>Kegiatan Yang Telah Berlalu</h2>
                </div>

                <div class="grid" style="gap:1rem;">
                    <?php $__currentLoopData = $lampau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('partials.kartu-agenda', ['item' => $item], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/public/agenda.blade.php ENDPATH**/ ?>