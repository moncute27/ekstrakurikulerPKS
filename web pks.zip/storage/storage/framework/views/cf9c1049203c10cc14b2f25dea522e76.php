<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Galeri - Admin PKS</title>

    <!-- Font Poppins -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backendgaleri.css')); ?>">
</head>

<body>

<div class="admin-container">

    <!-- ==================================================
         SIDEBAR
    ================================================== -->

    <aside class="sidebar">

        <!-- Logo + Nama Admin -->
        <div class="admin-profile">

            <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
                 alt="Logo PKS"
                 class="admin-logo">

            <div class="admin-title">
                <h2>ADMIN PKS</h2>
                <p>Ekstrakurikuler pks</p>
                <p>SMKN 2 PURWAKARTA</p>
            </div>

        </div>


        <!-- Menu -->
        <nav class="sidebar-menu">

            <a href="/admin/dashboard" class="menu-item">
                <i class="fa-solid fa-house"></i>
                <span>Dashboard</span>
            </a>

            <a href="/admin/profil" class="menu-item">
                <i class="fa-regular fa-user"></i>
                <span>Profil</span>
            </a>

            <a href="/admin/organisasi" class="menu-item">
                <i class="fa-solid fa-table-cells-large"></i>
                <span>Organisasi</span>
            </a>

            <a href="/admin/berita" class="menu-item">
                <i class="fa-solid fa-newspaper"></i>
                <span>Berita</span>
            </a>

            <!-- MENU AKTIF -->
            <a href="/admin/galeri" class="menu-item active">
                <i class="fa-regular fa-image"></i>
                <span>Galeri</span>
            </a>

            <a href="/admin/prestasi" class="menu-item">
                <i class="fa-solid fa-trophy"></i>
                <span>Prestasi</span>
            </a>

            <a href="/admin/anggota" class="menu-item">
                <i class="fa-solid fa-user-group"></i>
                <span>Anggota</span>
            </a>

            <a href="/admin/agenda" class="menu-item">
                <i class="fa-regular fa-calendar"></i>
                <span>Agenda</span>
            </a>

            <a href="/admin/user" class="menu-item">
                <i class="fa-regular fa-circle-user"></i>
                <span>User</span>
            </a>

        </nav>


        <!-- Logout -->
        <div class="logout-area">

            <a href="#" class="logout">
                <i class="fa-solid fa-right-from-bracket"></i>
                <span>Logout</span>
            </a>

        </div>

    </aside>



    <!-- ==================================================
         MAIN CONTENT
    ================================================== -->

    <main class="main-content">


        <!-- ================= HEADER ================= -->

        <header class="top-header">

            <!-- Hamburger -->
            <button class="hamburger">
                <i class="fa-solid fa-bars"></i>
            </button>


            <!-- Bagian kanan -->
            <div class="header-right">

                <!-- Notifikasi -->
                <i class="fa-solid fa-bell notification"></i>


                <!-- Admin -->
                <div class="user-profile">

                    <i class="fa-regular fa-circle-user user-icon"></i>

                    <div class="user-text">
                        <span>Admin PKS</span>
                        <small>Administrator</small>
                    </div>

                    <i class="fa-solid fa-chevron-down arrow"></i>

                </div>

            </div>

        </header>



        <!-- ================= ISI ================= -->

        <section class="content">


            <!-- Judul -->
            <div class="content-heading">

                <div>
                    <h1>Kelola Galeri</h1>

                    <p>
                        Kelola dokumentasi foto kegiatan PKS.
                    </p>
                </div>


                <!-- Search + Tambah -->
                <div class="action-area">

                    <div class="search-box">

                        <i class="fa-solid fa-magnifying-glass"></i>

                        <input type="text"
                               placeholder="Cari foto...">

                    </div>


                    <button class="add-button">
                        <i class="fa-solid fa-plus"></i>
                        Tambah Foto
                    </button>

                </div>

            </div>



            <!-- ================= GALERI ================= -->

            <div class="gallery-grid">


                <!-- FOTO 1 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/smk2.jpeg')); ?>"
                         alt="Penyerahan piala">

                    <p>
                        Dokumentasi penyerahan
                        piala lomba olimpiade smart
                        student
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>



                <!-- FOTO 2 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/ppbb.jpeg')); ?>"
                         alt="HUT Bhayangkara">

                    <p>
                        Dokumentasi peringatan
                        HUT bhayangkara ke-81
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>



                <!-- FOTO 3 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/plisi.jpg')); ?>"
                         alt="HUT Bhayangkara">

                    <p>
                        Dokumentasi peringatan
                        HUT bhayangkara ke-81
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>



                <!-- FOTO 4 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/smkn222.jpeg')); ?>"
                         alt="Penyerahan piala">

                    <p>
                        Dokumentasi penyerahan
                        piala lomba olimpiade smart
                        student
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>



                <!-- FOTO 5 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/plisi2.jpg')); ?>"
                         alt="Demo ekstrakurikuler">

                    <p>
                        Dokumentasi demo
                        ekstrakurikuler
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>



                <!-- FOTO 6 -->
                <div class="gallery-card">

                    <img src="<?php echo e(asset('img/honey.jpeg')); ?>"
                         alt="Serah terima jabatan">

                    <p>
                        Dokumentasi serah
                        terima jabatan
                    </p>

                    <div class="card-buttons">

                        <button class="edit-button">
                            <i class="fa-solid fa-pen"></i>
                            Edit
                        </button>

                        <button class="delete-button">
                            <i class="fa-regular fa-trash-can"></i>
                            Hapus
                        </button>

                    </div>

                </div>


            </div>

        </section>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    const hamburger = document.querySelector('.hamburger');
    const sidebar = document.querySelector('.sidebar');

    hamburger.addEventListener('click', function () {
        sidebar.classList.toggle('show');
    });

</script>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backendgaleri.blade.php ENDPATH**/ ?>