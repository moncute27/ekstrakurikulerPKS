<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Organisasi - Admin PKS</title>

    <link rel="stylesheet" href="<?php echo e(asset('backend/organisasi.css')); ?>">
</head>

<body>

<div class="admin-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <div class="sidebar-header">

            <div class="logo">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
            </div>

            <div class="admin-name">
                <h3>ADMIN PKS</h3>
                <p>Ekstrakurikuler pks</p>
                <p>SMKN 2 PURWAKARTA</p>
            </div>

        </div>


        <!-- MENU -->
        <nav class="sidebar-menu">

            <a href="dashboard" class="menu-item">
                <span class="menu-icon">⌂</span>
                <span>Dashboard</span>
            </a>

            <a href="/backendprofil" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>Profil</span>
            </a>

            <a href="/backendorganisasi" class="menu-item active">
                <span class="menu-icon">▱</span>
                <span>Organisasi</span>
            </a>

            <a href="/backendberita" class="menu-item">
                <span class="menu-icon">▤</span>
                <span>Berita</span>
            </a>

            <a href="/backendgaleri" class="menu-item">
                <span class="menu-icon">▣</span>
                <span>Galeri</span>
            </a>

            <a href="/backendprestasi" class="menu-item">
                <span class="menu-icon">♛</span>
                <span>Prestasi</span>
            </a>

            <a href="/backendanggota" class="menu-item">
                <span class="menu-icon">♟</span>
                <span>Anggota</span>
            </a>

            <a href="/backendagenda" class="menu-item">
                <span class="menu-icon">□</span>
                <span>Agenda</span>
            </a>

            <a href="/backenduser" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>User</span>
            </a>

        </nav>


        <!-- LOGOUT -->
        <div class="logout">

            <a href="logout">
                <span class="logout-icon">⇥</span>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->
    <main class="main-content">

        <!-- TOPBAR -->
        <header class="topbar">

            <button class="menu-toggle" id="menuToggle">
                ☰
            </button>

            <div class="topbar-right">

                <span class="notification">
                    ♟
                </span>

                <div class="profile-admin">

                    <span class="user-icon">
                        ●
                    </span>

                    <div class="admin-account">
                        <strong>Admin PKS</strong>
                        <small>Administrator</small>
                    </div>

                    <span class="arrow">⌄</span>

                </div>

            </div>

        </header>


        <!-- ================= ORGANISASI ================= -->
        <section class="organization-content">

            <!-- JUDUL -->
            <div class="organization-title">

                <h1>Kelola Organisasi</h1>

                <p>
                    Kelola data pengurus inti ekstrakurikuler PKS.
                </p>

            </div>


            <!-- ================= CARD PENGURUS ================= -->
            <div class="organization-card">

                <!-- HEADER CARD -->
                <div class="organization-card-header">

                    <div>
                        <h2>Pengurus inti</h2>

                        <p>
                            Daftar pengurus inti ekstrakurikuler PKS.
                        </p>
                    </div>

                    <button class="add-button">
                        <span>+</span>
                        Tambah Pengurus
                    </button>

                </div>


                <!-- ================= TABLE ================= -->
                <div class="table-wrapper">

                    <table class="organization-table">

                        <thead>

                            <tr>
                                <th>No.</th>
                                <th>Foto</th>
                                <th>Nama Pengurus</th>
                                <th>Jabatan</th>
                                <th>Kelas</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>

                        </thead>


                        <tbody>

                            <!-- DATA 1 -->
                            <tr>

                                <td>1.</td>

                                <td>
                                    <div class="member-photo">
                                        <img
                                            src="<?php echo e(asset('img/pembina.jpeg')); ?>"
                                            alt="Foto Pengurus"
                                        >
                                    </div>
                                </td>

                                <td>
                                    Lilis Aisyah Yunarti, S.Pd.
                                </td>

                                <td>
                                    PEMBINA
                                </td>

                                <td>
                                    -
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">

                                        <button
                                            class="edit-button"
                                            title="Edit"
                                        >
                                            ✎
                                        </button>

                                        <button
                                            class="delete-button"
                                            title="Hapus"
                                        >
                                            ▣
                                        </button>

                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 2 -->
                            <tr>

                                <td>2.</td>

                                <td>
                                    <div class="member-photo">
                                        <img
                                            src="<?php echo e(asset('img/pelatih.jpeg')); ?>"
                                            alt="Foto Pengurus"
                                        >
                                    </div>
                                </td>

                                <td>
                                    Lutfiah Aprilina
                                </td>

                                <td>
                                    PELATIH
                                </td>

                                <td>
                                    -
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">

                                        <button class="edit-button">
                                            ✎
                                        </button>

                                        <button class="delete-button">
                                            ▣
                                        </button>

                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 3 -->
                            <tr>

                                <td>3.</td>

                                <td></td>

                                <td>
                                    Natasya
                                </td>

                                <td>
                                    KETUA
                                </td>

                                <td>
                                    XII AK 3
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-button">✎</button>
                                        <button class="delete-button">▣</button>
                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 4 -->
                            <tr>

                                <td>4.</td>

                                <td></td>

                                <td>
                                    Aini Almaulida
                                </td>

                                <td>
                                    WAKIL
                                </td>

                                <td>
                                    XII DPB 1
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-button">✎</button>
                                        <button class="delete-button">▣</button>
                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 5 -->
                            <tr>

                                <td>5.</td>

                                <td></td>

                                <td>
                                    Esa Maesaroh
                                </td>

                                <td>
                                    SEKRETARIS
                                </td>

                                <td>
                                    XI TKJ 1
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-button">✎</button>
                                        <button class="delete-button">▣</button>
                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 6 -->
                            <tr>

                                <td>6.</td>

                                <td></td>

                                <td>
                                    Devi Nurwati
                                </td>

                                <td>
                                    BENDAHARA
                                </td>

                                <td>
                                    XI AK 2
                                </td>

                                <td>
                                    <span class="status inactive-status">
                                        Tidak Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-button">✎</button>
                                        <button class="delete-button">▣</button>
                                    </div>
                                </td>

                            </tr>


                            <!-- DATA 7 -->
                            <tr>

                                <td>7.</td>

                                <td></td>

                                <td>
                                    Revita Maulida
                                </td>

                                <td>
                                    HUMAS
                                </td>

                                <td>
                                    XI BD 1
                                </td>

                                <td>
                                    <span class="status active-status">
                                        Aktif
                                    </span>
                                </td>

                                <td>
                                    <div class="action-buttons">
                                        <button class="edit-button">✎</button>
                                        <button class="delete-button">▣</button>
                                    </div>
                                </td>

                            </tr>

                        </tbody>

                    </table>

                </div>

            </div>

        </section>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    const menuToggle = document.getElementById("menuToggle");
    const sidebar = document.querySelector(".sidebar");

    menuToggle.addEventListener("click", function () {

        sidebar.classList.toggle("show");

    });

</script>

</body>
</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backend/backendorganisasi.blade.php ENDPATH**/ ?>