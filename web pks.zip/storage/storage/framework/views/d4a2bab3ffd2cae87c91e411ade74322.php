<?php $__env->startSection('title', 'Kelola Agenda'); ?>
<?php $__env->startSection('subtitle', 'Jadwal kegiatan Ekstrakurikuler PKS'); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-head">
        <div>
            <h1>Kelola Agenda</h1>
            <p>Total <?php echo e($agenda->total()); ?> agenda tersimpan.</p>
        </div>

        <a href="<?php echo e(route('admin.agenda.create')); ?>" class="btn btn--gold">+ Tambah Agenda</a>
    </div>

    <div class="toolbar">
        <form method="GET" action="<?php echo e(route('admin.agenda.index')); ?>">
            <input type="search" name="cari" value="<?php echo e($cari); ?>" placeholder="Cari judul agenda...">
            <button type="submit" class="btn btn--primary">Cari</button>
            <?php if($cari): ?>
                <a href="<?php echo e(route('admin.agenda.index')); ?>" class="btn btn--light">Reset</a>
            <?php endif; ?>
        </form>
    </div>

    <div class="panel">
        <?php if($agenda->isEmpty()): ?>
            <div class="empty">
                <div class="empty__icon">📅</div>
                <p>Belum ada agenda kegiatan.</p>
            </div>
        <?php else: ?>
            <div class="table-scroll">
                <table class="data">
                    <thead>
                        <tr>
                            <th style="width:80px;">Tanggal</th>
                            <th>Kegiatan</th>
                            <th>Waktu</th>
                            <th>Lokasi</th>
                            <th>Status</th>
                            <th style="text-align:right;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $agenda; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="mini-date">
                                        <?php echo e($item->tanggal?->format('d')); ?>

                                        <span><?php echo e($item->tanggal?->translatedFormat('M Y')); ?></span>
                                    </div>
                                </td>
                                <td class="cell-title" style="max-width:320px;">
                                    <strong><?php echo e($item->judul); ?></strong>
                                    <small><?php echo e(\Illuminate\Support\Str::limit($item->deskripsi, 70)); ?></small>
                                </td>
                                <td><?php echo e($item->waktu ? \Illuminate\Support\Carbon::parse($item->waktu)->format('H:i') : '—'); ?></td>
                                <td><?php echo e($item->lokasi ?: '—'); ?></td>
                                <td>
                                    <span class="badge <?php echo e($item->sudah_lewat ? 'badge--grey' : 'badge--green'); ?>">
                                        <?php echo e($item->sudah_lewat ? 'Selesai' : 'Mendatang'); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="td-actions">
                                        <a href="<?php echo e(route('admin.agenda.edit', $item)); ?>" class="btn btn--light btn-icon" title="Edit">✎</a>
                                        <form method="POST" action="<?php echo e(route('admin.agenda.destroy', $item)); ?>"
                                              data-confirm="Hapus agenda &quot;<?php echo e($item->judul); ?>&quot;?">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn--danger btn-icon" title="Hapus">🗑</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="pagination-wrap"><?php echo e($agenda->links()); ?></div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\project\web-rpl\resources\views/admin/agenda/index.blade.php ENDPATH**/ ?>