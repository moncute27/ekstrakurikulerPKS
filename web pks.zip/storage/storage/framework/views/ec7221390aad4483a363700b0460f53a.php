<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Berita - Admin PKS</title>

    <link rel="stylesheet" href="<?php echo e(asset('backend/berita.css')); ?>">
</head>

<body>

<div class="admin-container">

    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">

        <!-- LOGO DAN IDENTITAS -->
        <div class="sidebar-header">

            <div class="logo">
                <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
            </div>

            <div class="admin-name">
                <h3>ADMIN PKS</h3>
                <p>Ekstrakurikuler pks</p>
                <p>SMKN 2 PURWAKARTA</p>
            </div>

        </div>


        <!-- ================= MENU ================= -->
        <nav class="sidebar-menu">

            <a href="dashboard" class="menu-item">
                <span class="menu-icon">⌂</span>
                <span>Dashboard</span>
            </a>

            <a href="/backendprofil" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>Profil</span>
            </a>

            <a href="/backendorganisasi" class="menu-item">
                <span class="menu-icon">▱</span>
                <span>Organisasi</span>
            </a>

            <a href="/backendberita" class="menu-item active">
                <span class="menu-icon">▤</span>
                <span>Berita</span>
            </a>

            <a href="/backendgaleri" class="menu-item">
                <span class="menu-icon">▣</span>
                <span>Galeri</span>
            </a>

            <a href="/backendprestasi" class="menu-item">
                <span class="menu-icon">♛</span>
                <span>Prestasi</span>
            </a>

            <a href="/backendanggota" class="menu-item">
                <span class="menu-icon">♟</span>
                <span>Anggota</span>
            </a>

            <a href="/backendagenda" class="menu-item">
                <span class="menu-icon">□</span>
                <span>Agenda</span>
            </a>

            <a href="/backenduser" class="menu-item">
                <span class="menu-icon">♙</span>
                <span>User</span>
            </a>

        </nav>


        <!-- ================= LOGOUT ================= -->
        <div class="logout">

            <a href="logout">
                <span class="logout-icon">⇥</span>
                <span>Logout</span>
            </a>

        </div>

    </aside>


    <!-- ================= MAIN ================= -->
    <main class="main-content">


        <!-- ================= TOPBAR ================= -->
        <header class="topbar">

            <button class="menu-toggle" id="menuToggle">
                ☰
            </button>

            <div class="topbar-right">

                <span class="notification">
                    ♟
                </span>

                <div class="profile-admin">

                    <span class="user-icon">
                        ●
                    </span>

                    <div class="admin-account">
                        <strong>Admin PKS</strong>
                        <small>Administrator</small>
                    </div>

                    <span class="arrow">
                        ⌄
                    </span>

                </div>

            </div>

        </header>


        <!-- ================= BERITA ================= -->
        <section class="news-content">


            <!-- JUDUL -->
            <div class="news-heading">

                <div>
                    <h1>Kelola Berita</h1>

                    <p>
                        Kelola semua berita dan informasi kegiatan PKS.
                    </p>
                </div>


                <!-- TAMBAH BERITA -->
                <button class="add-news-button">
                    <span>+</span>
                    Tambah Berita
                </button>

            </div>


            <!-- ================= SEARCH ================= -->
            <div class="news-search">

                <span class="search-icon">⌕</span>

                <input
                    type="text"
                    placeholder="Cari Berita..."
                >

            </div>


            <!-- ================= LIST BERITA ================= -->
            <div class="news-list">


                <!-- HEADER -->
                <div class="news-table-header">

                    <div>Foto</div>
                    <div>Judul Berita</div>
                    <div>Tanggal</div>
                    <div>Penulis</div>
                    <div>Aksi</div>

                </div>


                <!-- ================= BERITA 1 ================= -->
                <div class="news-row">

                    <div class="news-photo">

                        <img
                            src="<?php echo e(asset('img/smk2.jpeg')); ?>"
                            alt="Kegiatan Latihan Diksar PKS"
                        >

                    </div>


                    <div class="news-information">

                        <h3>
                           Penyerahan piala olimpiade smart student
                        </h3>

                        <p>
                            PKS menerima penghargaan dalam kegiatan
                            olimpiade smart student sebagai bentuk
                            apresiasi atas prestasi yang telah diraih.
                        </p>

                    </div>


                    <div class="news-date">
                        01 mei 2026
                    </div>


                    <div class="news-author">
                        Admin PKS
                    </div>


                    <div class="news-actions">

                        <button class="edit-news">
                            ✎
                        </button>

                        <button class="delete-news">
                            ▣
                        </button>

                    </div>

                </div>


                <!-- ================= BERITA 2 ================= -->
                <div class="news-row">

                    <div class="news-photo">

                        <img
                            src="<?php echo e(asset('img/ppbb.jpeg')); ?>"
                            alt="Pelantikan Pengurus PKS"
                        >

                    </div>


                    <div class="news-information">

                        <h3>
                            Peringatan HUT bhayangkara ke-81
                        </h3>

                        <p>
                            PKS turut berpasitipasi dalam kegiatan
                            peringatan HUT bhayangkara ke-81
                        </p>

                    </div>


                    <div class="news-date">
                        20 juni 2026
                    </div>


                    <div class="news-author">
                        Admin PKS
                    </div>


                    <div class="news-actions">

                        <button class="edit-news">
                            ✎
                        </button>

                        <button class="delete-news">
                            ▣
                        </button>

                    </div>

                </div>


                <!-- ================= BERITA 3 ================= -->
                <div class="news-row">

                    <div class="news-photo">

                        <img
                            src="<?php echo e(asset('img/honey.jpeg')); ?>"
                            alt="Penerimaan Penghargaan"
                        >

                    </div>


                    <div class="news-information">

                        <h3>
                            Serah terima jabatan pengurus PKS
                        </h3>

                        <p>
                            Kegiatan serah terima jabatan sebagai bagian
                            dari pergantian dan pelantikan kepengurusan PKS.
                        </p>

                    </div>


                    <div class="news-date">
                        10 juli 2026
                    </div>


                    <div class="news-author">
                        Admin PKS
                    </div>


                    <div class="news-actions">

                        <button class="edit-news">
                            ✎
                        </button>

                        <button class="delete-news">
                            ▣
                        </button>

                    </div>

                </div>


            </div>

        </section>

    </main>

</div>


<!-- ================= JAVASCRIPT ================= -->

<script>

    const menuToggle = document.getElementById("menuToggle");
    const sidebar = document.querySelector(".sidebar");

    menuToggle.addEventListener("click", function () {

        sidebar.classList.toggle("show");

    });

</script>

</body>

</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backend/backendberita.blade.php ENDPATH**/ ?>