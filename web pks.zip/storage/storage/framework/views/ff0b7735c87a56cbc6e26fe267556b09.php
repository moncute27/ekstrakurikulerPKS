<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Kelola Profil - Admin PKS</title>

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('backendprofil.css')); ?>">
</head>

<body>

    <div class="admin-container">

        <!-- ================= SIDEBAR ================= -->
        <aside class="sidebar">

            <!-- Logo & Nama -->
            <div class="sidebar-header">

                <div class="logo">
                    <img src="<?php echo e(asset('img/logo pks.jpeg')); ?>" alt="Logo PKS">
                </div>

                <div class="admin-name">
                    <h3>ADMIN PKS</h3>
                    <p>Ekstrakurikuler pks</p>
                    <p>SMKN 2 PURWAKARTA</p>
                </div>

            </div>


            <!-- Menu -->
            <nav class="sidebar-menu">

                <a href="dashboard" class="menu-item">
                    <span class="icon">⌂</span>
                    <span>Dashboard</span>
                </a>

                <a href="profil" class="menu-item active">
                    <span class="icon">♙</span>
                    <span>Profil</span>
                </a>

                <a href="organisasi" class="menu-item">
                    <span class="icon">▱</span>
                    <span>Organisasi</span>
                </a>

                <a href="berita" class="menu-item">
                    <span class="icon">▤</span>
                    <span>Berita</span>
                </a>

                <a href="galeri" class="menu-item">
                    <span class="icon">▣</span>
                    <span>Galeri</span>
                </a>

                <a href="prestasi" class="menu-item">
                    <span class="icon">♛</span>
                    <span>Prestasi</span>
                </a>

                <a href="anggota" class="menu-item">
                    <span class="icon">♟</span>
                    <span>Anggota</span>
                </a>

                <a href="agenda" class="menu-item">
                    <span class="icon">□</span>
                    <span>Agenda</span>
                </a>

                <a href="user" class="menu-item">
                    <span class="icon">♙</span>
                    <span>User</span>
                </a>

            </nav>


            <!-- Logout -->
            <div class="logout">

                <a href="logout">
                    <span class="logout-icon">⇥</span>
                    <span>Logout</span>
                </a>

            </div>

        </aside>


        <!-- ================= MAIN CONTENT ================= -->
        <main class="main-content">


            <!-- TOPBAR -->
            <header class="topbar">

                <button class="menu-toggle" id="menuToggle">
                    ☰
                </button>

                <div class="topbar-right">

                    <span class="notification">
                        ♟
                    </span>

                    <div class="profile-admin">

                        <span class="user-icon">
                            ●
                        </span>

                        <div>
                            <strong>Admin PKS</strong>
                            <small>Administrator</small>
                        </div>

                        <span class="arrow">
                           ⌄
                        </span>

                    </div>

                </div>

            </header>


            <!-- CONTENT -->
            <section class="content">

                <div class="page-title">
                    <h1>Kelola Profil</h1>

                    <p>
                        Kelola informasi profil ekstrakurikuler PKS.
                    </p>
                </div>


                <!-- FORM PROFIL -->
                <form>


                    <div class="profile-wrapper">


                        <!-- ================= PREVIEW LOGO ================= -->
                        <div class="card logo-card">

                            <h2>Preview Logo</h2>

                            <div class="logo-preview">

                                <img
                                    src="<?php echo e(asset('img/logo pks.jpeg')); ?>"
                                    alt="Logo Ekstrakurikuler PKS"
                                >

                            </div>

                            <p class="format">
                                Format PNG, JPG<br>
                                Ukuran maks 2MB
                            </p>


                            <label for="logo" class="upload-button">
                                ⇧ &nbsp; Ubah Logo
                            </label>

                            <input
                                type="file"
                                id="logo"
                                name="logo"
                                accept=".png,.jpg,.jpeg"
                            >

                        </div>


                        <!-- ================= INFORMASI PROFIL ================= -->
                        <div class="card information-card">

                            <h2>Informasi Profil</h2>


                            <!-- Nama -->
                            <div class="form-group">

                                <label for="nama">
                                    Nama Ekstrakurikuler
                                </label>

                                <input
                                    type="text"
                                    id="nama"
                                    name="nama"
                                    value="Ekstrakurikuler PKS"
                                >

                            </div>


                            <!-- Judul -->
                            <div class="form-group">

                                <label for="judul">
                                    Judul
                                </label>

                                <input
                                    type="text"
                                    id="judul"
                                    name="judul"
                                    value="Ekstrakurikuler PKS SMKN 2 PURWAKARTA"
                                >

                            </div>


                            <!-- Isi -->
                            <div class="form-group">

                                <label for="isi">
                                    Isi
                                </label>

                                <textarea
                                    id="isi"
                                    name="isi"
                                >Ekstrakurikuler PKS merupakan wadah pengembangan diri bagi siswa yang memiliki semangat dalam kedisiplinan, kepemimpinan, dan kepedulian terhadap lingkungan sekolah. PKS berkomitmen untuk membentuk karakter siswa yang bertanggung jawab, jujur, dan siap menjadi teladan di sekolah maupun di masyarakat.</textarea>

                            </div>

                        </div>

                    </div>


                    <!-- BUTTON -->
                    <div class="form-buttons">

                        <button type="button" class="btn-cancel">
                            Batal
                        </button>

                        <button type="submit" class="btn-save">
                            ▣ &nbsp; Simpan Perubahan
                        </button>

                    </div>


                </form>

            </section>

        </main>

    </div>


    <!-- JAVASCRIPT MENU MOBILE -->
    <script>

        const menuToggle = document.getElementById("menuToggle");
        const sidebar = document.querySelector(".sidebar");

        menuToggle.addEventListener("click", function () {

            sidebar.classList.toggle("show");

        });

    </script>

</body>

</html>
<?php /**PATH C:\xampp\project\web-rpl\resources\views/backendprofil.blade.php ENDPATH**/ ?>